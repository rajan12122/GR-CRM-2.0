const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const connectionString = process.env.DATABASE_URL || "postgresql://neondb_owner:npg_JawHR2QpBYk1@ep-orange-cell-ay4kys3m-pooler.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require";

const pool = new Pool({
  connectionString,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 15000
});

const metadataPath = path.join(__dirname, '../config/metadata.json');

async function queryWithRetry(queryText, params = [], maxRetries = 8, delayMs = 5000) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await pool.query(queryText, params);
      return res;
    } catch (err) {
      console.warn(`Query attempt ${attempt} failed: ${err.message}`);
      if (attempt === maxRetries) throw err;
      await new Promise(r => setTimeout(r, delayMs));
    }
  }
}

async function run() {
  try {
    console.log("Connected to database...");
    
    if (!fs.existsSync(metadataPath)) {
      console.error("Local metadata.json not found at:", metadataPath);
      process.exit(1);
    }
    
    const localMetadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
    console.log("Read local metadata.json successfully.");

    const res = await queryWithRetry(`
      INSERT INTO app_metadata (key, value)
      VALUES ('main_metadata', $1)
      ON CONFLICT (key) DO UPDATE SET value = $1
      RETURNING key;
    `, [JSON.stringify(localMetadata)]);

    console.log("Successfully forced database app_metadata update to match local metadata.json!", res.rows[0]);
  } catch (err) {
    console.error("Error during sync:", err);
  } finally {
    await pool.end();
    process.exit(0);
  }
}

run();
