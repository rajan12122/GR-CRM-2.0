require('dotenv').config({ path: 'c:/Users/Pankaj/OneDrive/Desktop/gr crm 2.0/backend/.env' });
const dbService = require('../services/dbService');

async function run() {
  try {
    const res = await dbService.getRecords('entity_contacts');
    console.log("Records length:", res.length);
    console.log("Sample record:", res[0]);
  } catch (err) {
    console.error("Failed to get records:", err);
  } finally {
    process.exit(0);
  }
}
run();
