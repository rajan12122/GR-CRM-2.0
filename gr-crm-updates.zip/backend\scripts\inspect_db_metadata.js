const { Pool } = require('pg');

const pool = new Pool({
  connectionString: "postgresql://neondb_owner:npg_JawHR2QpBYk1@ep-orange-cell-ay4kys3m-pooler.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
});

async function run() {
  try {
    const res = await pool.query("SELECT value FROM app_metadata WHERE key = 'main_metadata'");
    if (res.rows.length > 0) {
      const meta = res.rows[0].value;
      console.log("Modules in DB metadata:", Object.keys(meta.modules || {}));
      console.log("entity_contacts details in DB:", meta.modules?.entity_contacts);
    } else {
      console.log("No main_metadata found in database.");
    }
  } catch (err) {
    console.error("Failed to query DB:", err);
  } finally {
    pool.end();
  }
}
run();
