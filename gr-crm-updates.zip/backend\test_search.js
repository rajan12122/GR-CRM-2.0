const { Pool } = require('pg');
require('dotenv').config();
const { getRecords } = require('./services/dbService');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

async function main() {
  try {
    const res = await getRecords('leads', pool, { search: 'gagan' });
    console.log('Search results:', res);
  } catch (err) {
    console.error('Error during search:', err);
  } finally {
    await pool.end();
  }
}

main();
