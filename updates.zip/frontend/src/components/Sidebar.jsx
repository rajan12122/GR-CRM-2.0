import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Box, 
  Drawer, 
  List, 
  ListItem, 
  ListItemButton, 
  ListItemIcon, 
  ListItemText, 
  Typography, 
  Divider,
  Button,
  Collapse
} from '@mui/material';
import * as Icons from 'lucide-react';
import { useApp } from '../context/AppContext';

export const DynamicIcon = ({ name, size = 20, color = 'currentColor', ...props }) => {
  const IconComponent = Icons[name];
  if (!IconComponent) return <Icons.HelpCircle size={size} color={color} {...props} />;
  return <IconComponent size={size} color={color} {...props} />;
};

const DRAWER_WIDTH = 260;

const Sidebar = ({ mobileOpen, handleDrawerToggle }) => {
  const { metadata, logout, user, hasPermission } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [expandedCategories, setExpandedCategories] = React.useState({});

  const toggleCategory = (catId) => {
    setExpandedCategories(prev => ({
      ...prev,
      [catId]: !prev[catId]
    }));
  };

  if (!metadata) return null;

  const categories = metadata.sidebarCategories || [];

  // Group modules by category dynamically
  const groupedModules = (() => {
    const groupedKeys = new Set();
    const result = [];

    // 1. Process custom categories
    categories.forEach(cat => {
      const catModules = (cat.modules || [])
        .filter(key => (metadata.modules[key] || key === 'dashboard' || key === 'property_pipeline') && (key === 'dashboard' || key === 'property_pipeline' || hasPermission(key, 'view')))
        .map(key => {
          groupedKeys.add(key);
          if (key === 'dashboard') {
            return {
              id: key,
              label: 'Dashboard',
              icon: 'LayoutDashboard',
              path: '/'
            };
          }
          if (key === 'property_pipeline') {
            return {
              id: key,
              label: 'Property Pipeline',
              icon: 'Layers',
              path: '/pipeline/properties'
            };
          }
          return {
            id: key,
            label: metadata.modules[key].label,
            icon: metadata.modules[key].icon || 'Layers',
            path: `/module/${key}`
          };
        });

      if (catModules.length > 0) {
        result.push({
          id: cat.id,
          label: cat.label,
          description: cat.description,
          modules: catModules
        });
      }
    });

    // 2. Process uncategorized modules
    const uncategorizedModules = Object.keys(metadata.modules)
      .filter(key => !groupedKeys.has(key) && hasPermission(key, 'view'))
      .map(key => ({
        id: key,
        label: metadata.modules[key].label,
        icon: metadata.modules[key].icon || 'Layers',
        path: `/module/${key}`
      }));

    if (uncategorizedModules.length > 0) {
      result.push({
        id: 'uncategorized',
        label: categories.length > 0 ? 'Other Modules' : 'Modules',
        modules: uncategorizedModules
      });
    }

    return result;
  })();

  const activePath = location.pathname;

  const isModuleActive = (modulePath) => {
    return activePath === modulePath || activePath.startsWith(modulePath + '/');
  };

  // Auto-expand category containing the active module
  React.useEffect(() => {
    let catToExpand = null;
    if (activePath === '/sheets-mapping' || activePath === '/settings') {
      catToExpand = 'management';
    } else if (groupedModules && groupedModules.length > 0) {
      const activeCat = groupedModules.find(group => 
        group.modules.some(mod => isModuleActive(mod.path))
      );
      if (activeCat) {
        catToExpand = activeCat.id;
      }
    }
    if (catToExpand) {
      setExpandedCategories(prev => ({
        ...prev,
        [catToExpand]: true
      }));
    }
  }, [location.pathname, metadata]);

  const handleNavClick = (path) => {
    navigate(path);
    if (mobileOpen) {
      handleDrawerToggle(); // close drawer on mobile click
    }
  };

  const drawerContent = (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'space-between' }}>
      <Box sx={{ overflowY: 'auto', flex: 1, '&::-webkit-scrollbar': { width: '4px' }, '&::-webkit-scrollbar-thumb': { backgroundColor: '#334155', borderRadius: '4px' } }}>
        {/* Brand Header */}
        <Box sx={{ p: 2, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <Box component="img" src="/logo.jpg" alt="Gagan Realtech Logo" sx={{ 
            maxWidth: '100%', 
            height: 55,
            objectFit: 'contain',
            borderRadius: '6px'
          }} />
        </Box>

        <Divider sx={{ borderColor: '#1E293B', mb: 2 }} />



        {/* Workspace Link */}
        <List sx={{ px: 1.5, py: 0 }}>
          <ListItem disablePadding sx={{ mb: 0.5 }}>
            <ListItemButton
              onClick={() => handleNavClick('/workspace')}
              selected={activePath === '/workspace'}
              sx={{
                borderRadius: '8px',
                py: 1.2,
                px: 2,
                backgroundColor: activePath === '/workspace' ? 'rgba(37, 99, 235, 0.15) !important' : 'transparent',
                color: activePath === '/workspace' ? '#3B82F6' : '#94A3B8',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  color: '#FFFFFF'
                }
              }}
            >
              <ListItemIcon sx={{ minWidth: 40, color: 'inherit' }}>
                <Icons.Briefcase size={20} />
              </ListItemIcon>
              <ListItemText 
                primary="My Workspace" 
                primaryTypographyProps={{ fontSize: '14px', fontWeight: 600 }} 
              />
            </ListItemButton>
          </ListItem>
        </List>

        {/* Grouped Dynamic Schema Modules Links */}
        {groupedModules.map((group) => (
          <React.Fragment key={group.id}>
            <Box 
              onClick={() => toggleCategory(group.id)}
              sx={{ 
                px: 2, 
                py: 1.2, 
                mx: 1.5,
                mt: 1.5,
                mb: 0.5,
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'space-between',
                cursor: 'pointer',
                borderRadius: '6px',
                color: '#94A3B8',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  color: '#FFFFFF'
                },
                userSelect: 'none',
                transition: 'all 0.2s ease'
              }}
            >
              <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                <Typography 
                  variant="caption" 
                  sx={{ 
                    textTransform: 'uppercase', 
                    fontSize: '12.5px', // Increased size!
                    fontWeight: 800, // Thicker font!
                    letterSpacing: '0.05em',
                    fontFamily: 'Poppins, Roboto, sans-serif',
                    color: '#E2E8F0'
                  }}
                >
                  {group.label}
                </Typography>
                {group.description && (
                  <Typography 
                    variant="caption" 
                    sx={{ 
                      fontSize: '10.5px',
                      color: '#64748B',
                      fontWeight: 500,
                      mt: 0.25,
                      textTransform: 'none',
                      fontFamily: 'Inter, sans-serif'
                    }}
                  >
                    {group.description}
                  </Typography>
                )}
              </Box>
              {expandedCategories[group.id] ? (
                <Icons.ChevronDown size={16} sx={{ opacity: 0.8 }} />
              ) : (
                <Icons.ChevronRight size={16} sx={{ opacity: 0.8 }} />
              )}
            </Box>
            <Collapse in={!!expandedCategories[group.id]} timeout="auto" unmountOnExit>
              <List sx={{ px: 1.5, py: 0 }}>
                {group.modules.map((mod) => (
                  <ListItem key={mod.id} disablePadding sx={{ mb: 0.5 }}>
                    <ListItemButton
                      onClick={() => handleNavClick(mod.path)}
                      selected={isModuleActive(mod.path)}
                      sx={{
                        borderRadius: '8px',
                        py: 1.2,
                        px: 2,
                        backgroundColor: isModuleActive(mod.path) ? 'rgba(37, 99, 235, 0.15) !important' : 'transparent',
                        color: isModuleActive(mod.path) ? '#3B82F6' : '#94A3B8',
                        '&:hover': {
                          backgroundColor: 'rgba(255, 255, 255, 0.05)',
                          color: '#FFFFFF'
                        }
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: 40, color: 'inherit' }}>
                        <DynamicIcon name={mod.icon} size={20} />
                      </ListItemIcon>
                      <ListItemText 
                        primary={mod.label} 
                        primaryTypographyProps={{ fontSize: '14px', fontWeight: 600 }} 
                      />
                    </ListItemButton>
                  </ListItem>
                ))}
              </List>
            </Collapse>
          </React.Fragment>
        ))}



        {user?.role === 'Admin' && (
          <>
            <Box 
              onClick={() => toggleCategory('management')}
              sx={{ 
                px: 2, 
                py: 1, 
                mx: 1.5,
                mt: 1.5,
                mb: 0.5,
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'space-between',
                cursor: 'pointer',
                borderRadius: '6px',
                color: '#94A3B8',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  color: '#FFFFFF'
                },
                userSelect: 'none',
                transition: 'all 0.2s ease'
              }}
            >
              <Typography 
                variant="caption" 
                sx={{ 
                  textTransform: 'uppercase', 
                  fontSize: '12.5px',
                  fontWeight: 800,
                  letterSpacing: '0.05em',
                  fontFamily: 'Poppins, Roboto, sans-serif'
                }}
              >
                Management
              </Typography>
              {expandedCategories['management'] ? (
                <Icons.ChevronDown size={16} sx={{ opacity: 0.8 }} />
              ) : (
                <Icons.ChevronRight size={16} sx={{ opacity: 0.8 }} />
              )}
            </Box>
            <Collapse in={!!expandedCategories['management']} timeout="auto" unmountOnExit>
              <List sx={{ px: 1.5, py: 0 }}>
                <ListItem disablePadding sx={{ mb: 0.5 }}>
                  <ListItemButton
                    onClick={() => handleNavClick('/sheets-mapping')}
                    selected={activePath === '/sheets-mapping'}
                    sx={{
                      borderRadius: '8px',
                      py: 1.2,
                      px: 2,
                      backgroundColor: activePath === '/sheets-mapping' ? 'rgba(37, 99, 235, 0.15) !important' : 'transparent',
                      color: activePath === '/sheets-mapping' ? '#3B82F6' : '#94A3B8',
                      '&:hover': {
                        backgroundColor: 'rgba(255, 255, 255, 0.05)',
                        color: '#FFFFFF'
                      }
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: 40, color: 'inherit' }}>
                      <Icons.FileSpreadsheet size={20} />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Sheets Mapping" 
                      primaryTypographyProps={{ fontSize: '14px', fontWeight: 600 }} 
                    />
                  </ListItemButton>
                </ListItem>
                <ListItem disablePadding sx={{ mb: 0.5 }}>
                  <ListItemButton
                    onClick={() => handleNavClick('/settings')}
                    selected={activePath === '/settings'}
                    sx={{
                      borderRadius: '8px',
                      py: 1.2,
                      px: 2,
                      backgroundColor: activePath === '/settings' ? 'rgba(37, 99, 235, 0.15) !important' : 'transparent',
                      color: activePath === '/settings' ? '#3B82F6' : '#94A3B8',
                      '&:hover': {
                        backgroundColor: 'rgba(255, 255, 255, 0.05)',
                        color: '#FFFFFF'
                      }
                    }}
                  >
                    <ListItemIcon sx={{ minWidth: 40, color: 'inherit' }}>
                      <Icons.Settings size={20} />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Admin Control Panel" 
                      primaryTypographyProps={{ fontSize: '14px', fontWeight: 600 }} 
                    />
                  </ListItemButton>
                </ListItem>
              </List>
            </Collapse>
          </>
        )}


      </Box>

      {/* User Session Footer */}
      <Box sx={{ p: 2, backgroundColor: '#020617', borderTop: '1px solid #1E293B' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
          <Box sx={{ 
            width: 36, 
            height: 36, 
            borderRadius: '50%', 
            backgroundColor: '#3B82F6', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            color: '#FFFFFF',
            fontWeight: 700,
            fontSize: '14px'
          }}>
            {user?.name?.split(' ').map(n=>n[0]).join('') || 'U'}
          </Box>
          <Box sx={{ overflow: 'hidden' }}>
            <Typography variant="body2" noWrap sx={{ color: '#FFFFFF', fontWeight: 600 }}>
              {user?.name || 'User Profile'}
            </Typography>
            <Typography variant="caption" noWrap sx={{ color: '#64748B', display: 'block' }}>
              Role: {user?.role || 'Guest'}
            </Typography>
          </Box>
        </Box>
        <Button 
          variant="contained" 
          color="error" 
          fullWidth 
          size="small"
          onClick={logout}
          startIcon={<Icons.LogOut size={16} />}
          sx={{ borderRadius: '6px', py: 1 }}
        >
          Sign Out
        </Button>
      </Box>
    </Box>
  );

  return (
    <>
      {/* 1. Mobile Drawer (Temporary overlay) */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          [`& .MuiDrawer-paper`]: { 
            width: DRAWER_WIDTH, 
            boxSizing: 'border-box',
            backgroundColor: '#0F172A',
            color: '#E2E8F0',
            borderRight: 'none',
            height: '100%'
          },
        }}
      >
        {drawerContent}
      </Drawer>

      {/* 2. Desktop Drawer (Permanent sidebar) */}
      <Drawer
        variant="permanent"
        sx={{
          display: { xs: 'none', md: 'block' },
          width: DRAWER_WIDTH,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { 
            width: DRAWER_WIDTH, 
            boxSizing: 'border-box',
            backgroundColor: '#0F172A',
            color: '#E2E8F0',
            borderRight: 'none',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            height: '100%'
          },
        }}
        open
      >
        {drawerContent}
      </Drawer>
    </>
  );
};

export default Sidebar;
