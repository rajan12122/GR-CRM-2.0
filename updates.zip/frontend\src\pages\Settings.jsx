import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Card, 
  CardContent, 
  Typography, 
  Grid, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  TextField, 
  Button, 
  Divider, 
  Checkbox, 
  FormControlLabel, 
  Switch,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  List,
  ListSubheader,
  ListItem,
  Chip,
  CircularProgress,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import * as Icons from 'lucide-react';
import axios from 'axios';
import { useApp, API_BASE_URL } from '../context/AppContext';

const Settings = () => {
  const { 
    metadata, 
    saveMetadata, 
    testSheetsSync, 
    triggerFullSheetsSync,
    moduleData,
    fetchModuleData,
    updateRecord,
    triggerAppReload,
    logout
  } = useApp();

  useEffect(() => {
    fetchModuleData('employees');
  }, []);

  const [activeTab, setActiveTab] = useState('fields'); // 'fields', 'chips', 'permissions', 'sheets'
  const [selectedModule, setSelectedModule] = useState('customers');
  const [selectedChipGroup, setSelectedChipGroup] = useState('customerStages');
  const [statusMsg, setStatusMsg] = useState({ type: '', text: '' });
  const [syncLoading, setSyncLoading] = useState(false);
  const [permSelectedRole, setPermSelectedRole] = useState('Employee');
  const [permSelectedModule, setPermSelectedModule] = useState('customers');
  const [passwordSelectedEmp, setPasswordSelectedEmp] = useState('');
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [confirmPasswordVal, setConfirmPasswordVal] = useState('');
  const [selectedUserForPerms, setSelectedUserForPerms] = useState('');
  const [userPermSelectedModule, setUserPermSelectedModule] = useState('leads');

  // WhatsApp Integration States
  const [waGateway, setWaGateway] = useState('Simulator'); // Simulator, UltraMsg, Wassenger, Meta Cloud API, Custom API
  const [waApiKey, setWaApiKey] = useState('');
  const [waInstanceId, setWaInstanceId] = useState('');
  const [waSenderNumber, setWaSenderNumber] = useState('');
  
  // Custom WhatsApp Templates Lists
  const [waTemplatesList, setWaTemplatesList] = useState([]);
  const [newTemplateName, setNewTemplateName] = useState('');
  const [newTemplateBody, setNewTemplateBody] = useState('');
  
  // WhatsApp Campaign setup
  const [waRecipientType, setWaRecipientType] = useState('manual'); // manual, csv
  const [waManualNumbers, setWaManualNumbers] = useState('');
  const [waCsvNumbers, setWaCsvNumbers] = useState([]);
  const [waSelectedTemplate, setWaSelectedTemplate] = useState('');
  const [waMessageBody, setWaMessageBody] = useState('');
  const [waCampaignLoading, setWaCampaignLoading] = useState(false);
  const [waCampaignStatus, setWaCampaignStatus] = useState({ id: null, total: 0, sent: 0, failed: 0, status: 'idle', logs: [] });
  
  // Media files uploads
  const [waMediaFile, setWaMediaFile] = useState(null);
  const [waMediaUrl, setWaMediaUrl] = useState('');
  const [waMediaType, setWaMediaType] = useState(''); // image, video, document
  const [waUploadLoading, setWaUploadLoading] = useState(false);

  const handleSaveWaConfig = async () => {
    const updated = {
      ...metadata,
      whatsappConfig: {
        gateway: waGateway,
        apiKey: waApiKey,
        instanceId: waInstanceId,
        senderNumber: waSenderNumber
      }
    };
    const res = await saveMetadata(updated);
    if (res?.success !== false) {
      showStatus('success', 'WhatsApp configuration saved successfully!');
    } else {
      showStatus('error', 'Failed to save WhatsApp configuration.');
    }
  };

  const handleSaveWaTemplates = async (newTemplates) => {
    const updated = {
      ...metadata,
      whatsappTemplates: newTemplates
    };
    const res = await saveMetadata(updated);
    if (res?.success !== false) {
      setWaTemplatesList(newTemplates);
      showStatus('success', 'WhatsApp templates updated successfully!');
    } else {
      showStatus('error', 'Failed to update WhatsApp templates.');
    }
  };

  const handleMediaUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setWaMediaFile(file);
    setWaUploadLoading(true);

    if (file.type.startsWith('image/')) setWaMediaType('image');
    else if (file.type.startsWith('video/')) setWaMediaType('video');
    else setWaMediaType('document');

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const token = localStorage.getItem('gr_crm_token');
        const res = await axios.post(`${API_BASE_URL}/upload`, {
          fileName: file.name,
          base64Data: reader.result
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (res.data?.success) {
          setWaMediaUrl(res.data.fileUrl);
          showStatus('success', `Media file "${file.name}" uploaded successfully!`);
        } else {
          showStatus('error', 'Media upload failed.');
        }
      } catch (err) {
        console.error(err);
        showStatus('error', 'Media upload failed.');
      } finally {
        setWaUploadLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const parseCSV = (csvText) => {
    const lines = csvText.split('\n');
    const numbers = [];
    lines.forEach(line => {
      const cols = line.split(',');
      if (cols.length > 0) {
        const num = cols[0].replace(/[^0-9+]/g, '').trim();
        if (num && num.length >= 10) {
          numbers.push(num);
        }
      }
    });
    return numbers;
  };

  const handleCsvUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target.result;
      const parsedNumbers = parseCSV(csvText);
      setWaCsvNumbers(parsedNumbers);
      showStatus('success', `CSV parsed successfully! Found ${parsedNumbers.length} valid numbers.`);
    };
    reader.readAsText(file);
  };

  const handleStartCampaign = async () => {
    let numbers = [];
    if (waRecipientType === 'manual') {
      if (!waManualNumbers.trim()) {
        showStatus('error', 'Please enter at least one phone number.');
        return;
      }
      numbers = waManualNumbers
        .split(/[\n,]/)
        .map(n => n.replace(/[^0-9+]/g, '').trim())
        .filter(n => n.length >= 10);
    } else {
      if (waCsvNumbers.length === 0) {
        showStatus('error', 'Please upload a CSV file with valid phone numbers.');
        return;
      }
      numbers = waCsvNumbers;
    }

    if (numbers.length === 0) {
      showStatus('error', 'No valid recipient phone numbers found.');
      return;
    }

    if (!waMessageBody.trim()) {
      showStatus('error', 'Please enter a message body.');
      return;
    }

    setWaCampaignLoading(true);
    try {
      const token = localStorage.getItem('gr_crm_token');
      const res = await axios.post(`${API_BASE_URL}/whatsapp/send-bulk`, {
        numbers,
        message: waMessageBody,
        mediaUrl: waMediaUrl || undefined,
        mediaType: waMediaType || undefined,
        mediaName: waMediaFile ? waMediaFile.name : undefined,
        config: {
          gateway: waGateway,
          apiKey: waApiKey,
          instanceId: waInstanceId,
          senderNumber: waSenderNumber
        }
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.data?.success) {
        showStatus('success', 'Bulk sending campaign started successfully!');
        setWaCampaignStatus({
          id: res.data.campaignId,
          total: numbers.length,
          sent: 0,
          failed: 0,
          status: 'sending',
          logs: [`[${new Date().toLocaleTimeString()}] Campaign queued...`]
        });
      } else {
        showStatus('error', 'Failed to start campaign.');
        setWaCampaignLoading(false);
      }
    } catch (err) {
      console.error(err);
      showStatus('error', err.response?.data?.message || 'Failed to start campaign.');
      setWaCampaignLoading(false);
    }
  };

  const handleAbortCampaign = async () => {
    try {
      const token = localStorage.getItem('gr_crm_token');
      await axios.post(`${API_BASE_URL}/whatsapp/campaign-abort`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      showStatus('success', 'Campaign aborted successfully.');
      setWaCampaignStatus(prev => ({ ...prev, status: 'idle' }));
      setWaCampaignLoading(false);
    } catch (err) {
      console.error(err);
      showStatus('error', 'Failed to abort campaign.');
    }
  };

  const handleAddWaTemplate = () => {
    if (!newTemplateName.trim() || !newTemplateBody.trim()) {
      showStatus('error', 'Please enter template name and body.');
      return;
    }

    const newTemplates = [
      ...waTemplatesList,
      {
        id: 'T_' + Date.now(),
        name: newTemplateName,
        body: newTemplateBody
      }
    ];
    handleSaveWaTemplates(newTemplates);
    setNewTemplateName('');
    setNewTemplateBody('');
  };

  const handleDeleteWaTemplate = (id) => {
    const newTemplates = waTemplatesList.filter(t => t.id !== id);
    handleSaveWaTemplates(newTemplates);
  };

  useEffect(() => {
    let intervalId;
    if (waCampaignStatus.status === 'sending') {
      intervalId = setInterval(async () => {
        try {
          const token = localStorage.getItem('gr_crm_token');
          const res = await axios.get(`${API_BASE_URL}/whatsapp/campaign-status`, {
            headers: { Authorization: `Bearer ${token}` }
          });
          setWaCampaignStatus(res.data);
          if (res.data.status !== 'sending') {
            setWaCampaignLoading(false);
          }
        } catch (err) {
          console.error('Error polling campaign status:', err);
        }
      }, 1000);
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [waCampaignStatus.status]);

  const handleGenerateIntakeLink = async () => {
    setIntakeLoading(true);
    setIntakeError('');
    try {
      const token = localStorage.getItem('gr_crm_token');
      const res = await axios.get(`${API_BASE_URL}/public/generate-intake-token`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.data.success) {
        setIntakeToken(res.data.token);
      } else {
        setIntakeError('Failed to generate intake link.');
      }
    } catch (err) {
      console.error(err);
      setIntakeError(err.response?.data?.error || 'Failed to generate intake link.');
    } finally {
      setIntakeLoading(false);
    }
  };



  // Lead Rotation local form states
  const [rotationActive, setRotationActive] = useState(false);
  const [rotationHours, setRotationHours] = useState('24');
  const [rotatedSources, setRotatedSources] = useState([]);

  // Message templates form states
  const [whatsappTemplate, setWhatsappTemplate] = useState('');
  const [emailSubjectTemplate, setEmailSubjectTemplate] = useState('');
  const [emailBodyTemplate, setEmailBodyTemplate] = useState('');
  const [smsTemplate, setSmsTemplate] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('gr_crm_token');
    axios.get(`${API_BASE_URL}/templates`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => {
      setWhatsappTemplate(res.data.whatsapp || '');
      setEmailSubjectTemplate(res.data.email_subject || '');
      setEmailBodyTemplate(res.data.email_body || '');
      setSmsTemplate(res.data.sms || '');
    }).catch(err => console.error('Failed to load templates:', err));
  }, []);

  const handleSaveTemplates = async () => {
    const token = localStorage.getItem('gr_crm_token');
    try {
      await axios.post(`${API_BASE_URL}/templates`, {
        whatsapp: whatsappTemplate,
        email_subject: emailSubjectTemplate,
        email_body: emailBodyTemplate,
        sms: smsTemplate
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      showStatus('success', 'Message templates saved successfully!');
    } catch (e) {
      console.error(e);
      showStatus('error', 'Failed to save message templates.');
    }
  };

  // Google Sheets local form state
  const [sheetsId, setSheetsId] = useState('');
  const [sheetsEmail, setSheetsEmail] = useState('');
  const [sheetsKey, setSheetsKey] = useState('');
  const [sheetsActive, setSheetsActive] = useState(false);

  useEffect(() => {
    if (metadata?.sheetsConfig) {
      setSheetsId(metadata.sheetsConfig.spreadsheetId || '');
      setSheetsEmail(metadata.sheetsConfig.clientEmail || '');
      setSheetsKey(metadata.sheetsConfig.privateKey || '');
      setSheetsActive(metadata.sheetsConfig.syncActive || false);
    }
    if (metadata?.automationConfig) {
      setRotationActive(metadata.automationConfig.leadRotationActive || false);
      setRotationHours(metadata.automationConfig.rotationHours || '24');
      setRotatedSources(metadata.automationConfig.rotatedSources || []);
    }
    if (metadata?.whatsappConfig) {
      setWaGateway(metadata.whatsappConfig.gateway || 'Simulator');
      setWaApiKey(metadata.whatsappConfig.apiKey || '');
      setWaInstanceId(metadata.whatsappConfig.instanceId || '');
      setWaSenderNumber(metadata.whatsappConfig.senderNumber || '');
    }
    if (metadata?.whatsappTemplates) {
      setWaTemplatesList(metadata.whatsappTemplates || []);
    }
  }, [metadata]);

  const handleSaveRotationSettings = async () => {
    const updated = {
      ...metadata,
      automationConfig: {
        leadRotationActive: rotationActive,
        rotationHours: rotationHours,
        rotatedSources: rotatedSources
      }
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', 'Lead rotation engine settings updated successfully!');
    } else {
      showStatus('error', res.message);
    }
  };

  // Field Add Form state
  const [newFieldName, setNewFieldName] = useState('');
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldType, setNewFieldType] = useState('text');
  const [newFieldRequired, setNewFieldRequired] = useState(false);
  const [newFieldShowTable, setNewFieldShowTable] = useState(true);
  const [newFieldChipGroup, setNewFieldChipGroup] = useState('');
  const [newFieldRefModule, setNewFieldRefModule] = useState('');
  const [editingField, setEditingField] = useState(null);
  const [draggedIndex, setDraggedIndex] = useState(null);

  const [newChipVal, setNewChipVal] = useState('');
  const [newChipLabel, setNewChipLabel] = useState('');
  const [newChipColor, setNewChipColor] = useState('#2563EB');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingChipIndex, setEditingChipIndex] = useState(null);

  // Sidebar categories states
  const [sidebarCategoryInputName, setSidebarCategoryInputName] = useState('');
  const [sidebarEditingCategoryId, setSidebarEditingCategoryId] = useState('');
  const [sidebarEditingCategoryLabel, setSidebarEditingCategoryLabel] = useState('');

  if (!metadata) return null;

  const showStatus = (type, text) => {
    setStatusMsg({ type, text });
    setTimeout(() => setStatusMsg({ type: '', text: '' }), 5000);
  };

  // --- SIDEBAR CATEGORIES MANAGEMENT ---

  const handleAddSidebarCategory = async (e) => {
    e.preventDefault();
    const catName = sidebarCategoryInputName.trim();
    if (!catName) {
      showStatus('error', 'Category name cannot be empty.');
      return;
    }
    const catId = catName.toLowerCase().replace(/[^a-z0-9]/g, '_');
    if (!catId) {
      showStatus('error', 'Category name must contain letters or numbers.');
      return;
    }
    const currentCats = metadata.sidebarCategories || [];
    if (currentCats.some(c => c.id === catId)) {
      showStatus('error', 'A sidebar group with this name already exists.');
      return;
    }
    const updated = {
      ...metadata,
      sidebarCategories: [
        ...currentCats,
        {
          id: catId,
          label: catName,
          modules: []
        }
      ]
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      setSidebarCategoryInputName('');
      showStatus('success', `Sidebar group "${catName}" added successfully.`);
    } else {
      showStatus('error', res.message || 'Failed to add sidebar group.');
    }
  };

  const handleDeleteSidebarCategory = async (catId) => {
    const currentCats = metadata.sidebarCategories || [];
    const updated = {
      ...metadata,
      sidebarCategories: currentCats.filter(c => c.id !== catId)
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', 'Sidebar group deleted successfully.');
    } else {
      showStatus('error', res.message || 'Failed to delete group.');
    }
  };

  const handleRenameSidebarCategory = async (catId) => {
    const label = sidebarEditingCategoryLabel.trim();
    if (!label) {
      showStatus('error', 'Sidebar group name cannot be empty.');
      return;
    }
    const currentCats = metadata.sidebarCategories || [];
    const updated = {
      ...metadata,
      sidebarCategories: currentCats.map(c => c.id === catId ? { ...c, label } : c)
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      setSidebarEditingCategoryId('');
      showStatus('success', 'Sidebar group renamed successfully.');
    } else {
      showStatus('error', res.message || 'Failed to rename group.');
    }
  };

  const handleMoveSidebarModule = async (moduleKey, targetCatId) => {
    const currentCats = metadata.sidebarCategories || [];
    const updatedCats = currentCats.map(c => {
      // Remove from current category
      let updatedModules = (c.modules || []).filter(m => m !== moduleKey);
      // Add to target category
      if (c.id === targetCatId) {
        updatedModules = [...updatedModules, moduleKey];
      }
      return { ...c, modules: updatedModules };
    });
    const updated = {
      ...metadata,
      sidebarCategories: updatedCats
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', `Moved module to new category.`);
    } else {
      showStatus('error', res.message || 'Failed to move module.');
    }
  };

  const handleReorderSidebarCategory = async (catId, direction) => {
    const currentCats = [...(metadata.sidebarCategories || [])];
    const index = currentCats.findIndex(c => c.id === catId);
    if (index === -1) return;
    if (direction === 'up' && index > 0) {
      const temp = currentCats[index];
      currentCats[index] = currentCats[index - 1];
      currentCats[index - 1] = temp;
    } else if (direction === 'down' && index < currentCats.length - 1) {
      const temp = currentCats[index];
      currentCats[index] = currentCats[index + 1];
      currentCats[index + 1] = temp;
    }
    const updated = {
      ...metadata,
      sidebarCategories: currentCats
    };
    const res = await saveMetadata(updated);
    if (!res.success) {
      showStatus('error', 'Failed to reorder categories.');
    }
  };

  // --- FIELDS SCHEMA SCHEMA MANAGEMENT ---

  const handleAddField = async (e) => {
    e.preventDefault();
    if (!newFieldName.trim() || !newFieldLabel.trim()) {
      showStatus('error', 'Field Name and Label are required.');
      return;
    }

    const updated = { ...metadata };
    const fields = updated.modules[selectedModule].fields;

    const newField = {
      name: newFieldName.trim(),
      label: newFieldLabel.trim(),
      type: newFieldType,
      required: newFieldRequired,
      showInTable: newFieldShowTable,
      editable: true
    };

    if (newFieldType === 'select' && newFieldChipGroup) {
      newField.chipGroup = newFieldChipGroup;
    }
    if (newFieldType === 'ref' && newFieldRefModule) {
      newField.refModule = newFieldRefModule;
    }

    if (editingField) {
      const idx = fields.findIndex(f => f.name === editingField.name);
      if (idx !== -1) {
        fields[idx] = newField;
      }
    } else {
      // Check duplicate
      if (fields.some(f => f.name === newFieldName)) {
        showStatus('error', `Field name '${newFieldName}' already exists in this module.`);
        return;
      }
      fields.push(newField);
    }

    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', editingField ? `Field schema '${newFieldLabel}' updated successfully.` : `Added field '${newFieldLabel}' successfully.`);
      setEditingField(null);
      setNewFieldName('');
      setNewFieldLabel('');
      setNewFieldType('text');
      setNewFieldRequired(false);
      setNewFieldShowTable(true);
      setNewFieldChipGroup('');
      setNewFieldRefModule('');
    } else {
      showStatus('error', res.message);
    }
  };

  const handleStartEditField = (field) => {
    setEditingField(field);
    setNewFieldName(field.name);
    setNewFieldLabel(field.label);
    setNewFieldType(field.type);
    setNewFieldRequired(field.required || false);
    setNewFieldShowTable(field.showInTable !== false);
    setNewFieldChipGroup(field.chipGroup || '');
    setNewFieldRefModule(field.refModule || '');
  };

  const handleCancelEditField = () => {
    setEditingField(null);
    setNewFieldName('');
    setNewFieldLabel('');
    setNewFieldType('text');
    setNewFieldRequired(false);
    setNewFieldShowTable(true);
    setNewFieldChipGroup('');
    setNewFieldRefModule('');
  };

  const handleMoveFieldUp = async (fieldName) => {
    const updated = { ...metadata };
    const fields = updated.modules[selectedModule].fields;
    const idx = fields.findIndex(f => f.name === fieldName);
    if (idx > 0) {
      const temp = fields[idx];
      fields[idx] = fields[idx - 1];
      fields[idx - 1] = temp;

      const res = await saveMetadata(updated);
      if (res.success) {
        showStatus('success', `Moved field '${fieldName}' up.`);
      } else {
        showStatus('error', res.message);
      }
    }
  };

  const handleMoveFieldDown = async (fieldName) => {
    const updated = { ...metadata };
    const fields = updated.modules[selectedModule].fields;
    const idx = fields.findIndex(f => f.name === fieldName);
    if (idx !== -1 && idx < fields.length - 1) {
      const temp = fields[idx];
      fields[idx] = fields[idx + 1];
      fields[idx + 1] = temp;

      const res = await saveMetadata(updated);
      if (res.success) {
        showStatus('success', `Moved field '${fieldName}' down.`);
      } else {
        showStatus('error', res.message);
      }
    }
  };

  const handleDragStart = (e, index) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = async (e, targetIndex) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === targetIndex) return;

    const updated = { ...metadata };
    const fields = [...updated.modules[selectedModule].fields];
    
    // Swap item positions
    const [draggedItem] = fields.splice(draggedIndex, 1);
    fields.splice(targetIndex, 0, draggedItem);
    
    updated.modules[selectedModule].fields = fields;

    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', 'Field alignment updated successfully.');
    } else {
      showStatus('error', res.message);
    }
    setDraggedIndex(null);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
  };

  const indexToAlphabet = (index) => {
    let temp = index;
    let label = '';
    while (temp >= 0) {
      label = String.fromCharCode((temp % 26) + 65) + label;
      temp = Math.floor(temp / 26) - 1;
    }
    return label;
  };

  const alphabetToIndex = (str) => {
    const clean = str.toUpperCase().trim().replace(/[^A-Z]/g, '');
    if (!clean) return -1;
    let index = 0;
    for (let i = 0; i < clean.length; i++) {
      index = index * 26 + (clean.charCodeAt(i) - 64);
    }
    return index - 1;
  };

  const handleAlphabetPositionChange = async (fieldName, alphabetStr) => {
    const cleanStr = alphabetStr.toUpperCase().trim().replace(/[^A-Z]/g, '');
    if (!cleanStr) return;

    const targetIdx = alphabetToIndex(cleanStr);
    if (targetIdx < 0) return;

    const updated = { ...metadata };
    const fields = [...updated.modules[selectedModule].fields];
    const idx = fields.findIndex(f => f.name === fieldName);
    if (idx === -1) return;

    let finalTargetIdx = targetIdx;
    if (finalTargetIdx >= fields.length) {
      finalTargetIdx = fields.length - 1;
    }

    if (idx === finalTargetIdx) return;

    // Reposition item
    const [item] = fields.splice(idx, 1);
    fields.splice(finalTargetIdx, 0, item);

    updated.modules[selectedModule].fields = fields;

    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', `Position for '${fieldName}' updated to '${cleanStr}'.`);
    } else {
      showStatus('error', res.message);
    }
  };

  const handleDeleteField = async (fieldName) => {
    if (fieldName === 'id') {
      showStatus('error', 'Cannot delete primary identifier field "id".');
      return;
    }
    if (window.confirm(`Delete field '${fieldName}' from module schema?`)) {
      const updated = { ...metadata };
      updated.modules[selectedModule].fields = updated.modules[selectedModule].fields.filter(f => f.name !== fieldName);
      const res = await saveMetadata(updated);
      if (res.success) {
        showStatus('success', `Field '${fieldName}' removed from schema.`);
      } else {
        showStatus('error', res.message);
      }
    }
  };

  // --- CHIPS OPTIONS MANAGEMENT ---

  const handleAddChip = async (e) => {
    e.preventDefault();
    if (!newChipVal.trim() || !newChipLabel.trim()) {
      showStatus('error', 'Option Value and Label are required.');
      return;
    }

    const updated = { ...metadata };
    if (!updated.chips[selectedChipGroup]) {
      updated.chips[selectedChipGroup] = [];
    }

    const choices = updated.chips[selectedChipGroup];

    if (editingChipIndex !== null && editingChipIndex !== undefined) {
      if (choices.some((c, idx) => idx !== editingChipIndex && c.value === newChipVal.trim())) {
        showStatus('error', 'Option value already exists.');
        return;
      }
      choices[editingChipIndex] = {
        value: newChipVal.trim(),
        label: newChipLabel.trim(),
        color: newChipColor
      };
    } else {
      if (choices.some(c => c.value === newChipVal.trim())) {
        showStatus('error', 'Option value already exists.');
        return;
      }
      choices.push({
        value: newChipVal.trim(),
        label: newChipLabel.trim(),
        color: newChipColor
      });
    }

    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', editingChipIndex !== null ? 'Dropdown option updated successfully.' : `Added dropdown option '${newChipLabel}' successfully.`);
      setNewChipVal('');
      setNewChipLabel('');
      setNewChipColor('#2563EB');
      setEditingChipIndex(null);
    } else {
      showStatus('error', res.message);
    }
  };

  const handleStartEditChip = (chip, index) => {
    setNewChipVal(chip.value);
    setNewChipLabel(chip.label);
    setNewChipColor(chip.color || '#2563EB');
    setEditingChipIndex(index);
  };

  const handleCancelEditChip = () => {
    setNewChipVal('');
    setNewChipLabel('');
    setNewChipColor('#2563EB');
    setEditingChipIndex(null);
  };

  const handleDeleteChip = async (val) => {
    if (window.confirm(`Delete dropdown option '${val}'?`)) {
      const updated = { ...metadata };
      updated.chips[selectedChipGroup] = updated.chips[selectedChipGroup].filter(c => c.value !== val);
      const res = await saveMetadata(updated);
      if (res.success) {
        showStatus('success', 'Dropdown option removed.');
        setEditingChipIndex(null);
      } else {
        showStatus('error', res.message);
      }
    }
  };

  const handleShiftChip = async (groupName, index, direction) => {
    const updated = { ...metadata };
    if (!updated.chips || !updated.chips[groupName]) return;
    const array = [...updated.chips[groupName]];
    
    if (direction === 'up' && index > 0) {
      const temp = array[index];
      array[index] = array[index - 1];
      array[index - 1] = temp;
    } else if (direction === 'down' && index < array.length - 1) {
      const temp = array[index];
      array[index] = array[index + 1];
      array[index + 1] = temp;
    }

    updated.chips[groupName] = array;
    const res = await saveMetadata(updated);
    if (res.success) {
      setEditingChipIndex(null);
    } else {
      showStatus('error', res.message);
    }
  };

  const handleFieldLabelChange = (val) => {
    setNewFieldLabel(val);
    const slug = val.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    setNewFieldName(slug);
  };

  const handleChipLabelChange = (val) => {
    setNewChipLabel(val);
    const slug = val.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    setNewChipVal(slug);
  };

  const handleCreateCategory = async (e) => {
    e.preventDefault();
    const name = newCategoryName.trim();
    if (!name) {
      showStatus('error', 'Please enter a category name.');
      return;
    }

    // Validate key (lowercase, alphanumeric, no spaces, starts with letter)
    if (!/^[a-z_][a-z0-9_]*$/.test(name)) {
      showStatus('error', 'Category key must be lowercase alphanumeric with no spaces (e.g. lead_sources).');
      return;
    }

    if (metadata.chips[name]) {
      showStatus('error', 'A category with this key already exists.');
      return;
    }

    const updated = { ...metadata };
    updated.chips[name] = []; // initialize as empty array

    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', `Dropdown Category '${name}' created successfully!`);
      setSelectedChipGroup(name);
      setNewCategoryName('');
    } else {
      showStatus('error', res.message);
    }
  };

  // --- PERMISSIONS MANAGEMENT ---

  const handlePermissionToggle = async (roleName, moduleKey, action) => {
    const updated = { ...metadata };
    if (!updated.rolesPermissions[roleName]) {
      updated.rolesPermissions[roleName] = {};
    }
    if (!updated.rolesPermissions[roleName][moduleKey]) {
      updated.rolesPermissions[roleName][moduleKey] = [];
    }

    const perms = updated.rolesPermissions[roleName][moduleKey];
    if (perms.includes(action)) {
      updated.rolesPermissions[roleName][moduleKey] = perms.filter(a => a !== action);
    } else {
      updated.rolesPermissions[roleName][moduleKey].push(action);
    }

    const res = await saveMetadata(updated);
    if (!res.success) {
      showStatus('error', res.message);
    }
  };

  const handleFieldPermissionToggle = async (roleName, moduleKey, fieldName) => {
    const updated = { ...metadata };
    if (!updated.fieldPermissions) {
      updated.fieldPermissions = {};
    }
    if (!updated.fieldPermissions[roleName]) {
      updated.fieldPermissions[roleName] = {};
    }
    if (!updated.fieldPermissions[roleName][moduleKey]) {
      // Default to all fields allowed if never customized before
      const allFields = updated.modules[moduleKey].fields.map(f => f.name);
      updated.fieldPermissions[roleName][moduleKey] = allFields;
    }

    const allowed = updated.fieldPermissions[roleName][moduleKey];
    if (allowed.includes(fieldName)) {
      updated.fieldPermissions[roleName][moduleKey] = allowed.filter(f => f !== fieldName);
    } else {
      updated.fieldPermissions[roleName][moduleKey].push(fieldName);
    }

    const res = await saveMetadata(updated);
    if (!res.success) {
      showStatus('error', res.message);
    }
  };

  const handleUserPermissionToggle = async (userId, moduleKey, action) => {
    const updated = { ...metadata };
    if (!updated.userPermissions) {
      updated.userPermissions = {};
    }
    if (!updated.userPermissions[userId]) {
      const emp = (moduleData.employees || []).find(e => String(e.id) === String(userId));
      const role = emp?.role || 'Employee';
      updated.userPermissions[userId] = JSON.parse(JSON.stringify(updated.rolesPermissions[role] || {}));
    }
    if (!updated.userPermissions[userId][moduleKey]) {
      updated.userPermissions[userId][moduleKey] = [];
    }

    const perms = updated.userPermissions[userId][moduleKey];
    if (perms.includes(action)) {
      updated.userPermissions[userId][moduleKey] = perms.filter(a => a !== action);
    } else {
      updated.userPermissions[userId][moduleKey].push(action);
    }

    const res = await saveMetadata(updated);
    if (!res.success) {
      showStatus('error', res.message);
    }
  };

  const handleUserColumnPermissionToggle = async (userId, moduleKey, columnName, action) => {
    const updated = { ...metadata };
    if (!updated.userColumnPermissions) {
      updated.userColumnPermissions = {};
    }
    if (!updated.userColumnPermissions[userId]) {
      updated.userColumnPermissions[userId] = {};
    }
    if (!updated.userColumnPermissions[userId][moduleKey]) {
      updated.userColumnPermissions[userId][moduleKey] = {};
    }
    if (!updated.userColumnPermissions[userId][moduleKey][columnName]) {
      updated.userColumnPermissions[userId][moduleKey][columnName] = ["view", "edit"];
    }

    const current = updated.userColumnPermissions[userId][moduleKey][columnName];
    if (current.includes(action)) {
      updated.userColumnPermissions[userId][moduleKey][columnName] = current.filter(a => a !== action);
    } else {
      updated.userColumnPermissions[userId][moduleKey][columnName].push(action);
    }

    const res = await saveMetadata(updated);
    if (!res.success) {
      showStatus('error', res.message);
    }
  };

  const handleResetUserPermissions = async (userId) => {
    if (!window.confirm("Are you sure you want to reset this user's custom permissions? They will revert to default role permissions.")) return;
    const updated = { ...metadata };
    let changed = false;
    if (updated.userPermissions && updated.userPermissions[userId]) {
      delete updated.userPermissions[userId];
      changed = true;
    }
    if (updated.userColumnPermissions && updated.userColumnPermissions[userId]) {
      delete updated.userColumnPermissions[userId];
      changed = true;
    }
    if (changed) {
      const res = await saveMetadata(updated);
      if (res.success) {
        showStatus('success', 'Reset user permissions to default role permissions.');
      } else {
        showStatus('error', res.message);
      }
    }
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    if (!passwordSelectedEmp || !newPasswordVal || !confirmPasswordVal) {
      showStatus('error', 'Please fill in all fields.');
      return;
    }

    if (newPasswordVal !== confirmPasswordVal) {
      showStatus('error', 'Passwords do not match.');
      return;
    }

    // Password strength validation regex
    const strengthRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
    if (!strengthRegex.test(newPasswordVal)) {
      showStatus('error', 'Password must be at least 8 characters, with an uppercase letter, a lowercase letter, a number, and a special character.');
      return;
    }

    try {
      const token = localStorage.getItem('gr_crm_token');
      const response = await axios.post(`${API_BASE_URL}/auth/admin/reset-password`, {
        employeeId: passwordSelectedEmp,
        password: newPasswordVal,
        confirmPassword: confirmPasswordVal
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.data.success) {
        showStatus('success', response.data.message || 'Password updated successfully!');
        setNewPasswordVal('');
        setConfirmPasswordVal('');
      } else {
        showStatus('error', response.data.message || 'Failed to update password.');
      }
    } catch (err) {
      showStatus('error', err.response?.data?.message || 'Server error. Password update failed.');
    }
  };

  // --- GOOGLE SHEETS SETTINGS MANAGEMENT ---

  const handleSheetsConfigChange = (field, val) => {
    const updated = { ...metadata };
    updated.sheetsConfig[field] = val;
    saveMetadata(updated);
  };

  const handleSaveSheetsConfig = async (e) => {
    e.preventDefault();
    const updated = { ...metadata };
    updated.sheetsConfig = {
      spreadsheetId: sheetsId.trim(),
      clientEmail: sheetsEmail.trim(),
      privateKey: sheetsKey,
      syncActive: sheetsActive
    };
    const res = await saveMetadata(updated);
    if (res.success) {
      showStatus('success', 'Google Sheets configuration saved successfully!');
    } else {
      showStatus('error', res.message);
    }
  };

  const handleTestSheets = async () => {
    setSyncLoading(true);
    const res = await testSheetsSync();
    setSyncLoading(false);
    if (res.success) {
      showStatus('success', res.message);
    } else {
      showStatus('error', res.message);
    }
  };

  const handleSyncNow = async () => {
    setSyncLoading(true);
    const res = await triggerFullSheetsSync();
    setSyncLoading(false);
    if (res.success) {
      showStatus('success', res.message);
    } else {
      showStatus('error', res.message);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Title */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h2" sx={{ fontWeight: 800, fontSize: '26px', color: '#0F172A', fontFamily: 'Poppins' }}>
          Admin Settings & Metadata Editor
        </Typography>
        <Typography variant="body2" sx={{ color: '#64748B' }}>
          Fully customize tables, columns, dropdown chips, roles, and permissions without writing code.
        </Typography>
      </Box>

      {/* Settings Menu Tabs */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
            <CardContent sx={{ p: 1.5 }}>
              <List disablePadding>
                <ListItem button onClick={() => setActiveTab('fields')} selected={activeTab === 'fields'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'fields' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'fields' ? '#2563EB' : '#4B5563' }}>
                  <Icons.Columns size={18} style={{ marginRight: 10 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>Custom Columns & Fields</Typography>
                </ListItem>
                <ListItem button onClick={() => setActiveTab('chips')} selected={activeTab === 'chips'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'chips' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'chips' ? '#2563EB' : '#4B5563' }}>
                  <Icons.Tag size={18} style={{ marginRight: 10 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>Chips & Dropdowns</Typography>
                </ListItem>
                <ListItem button onClick={() => setActiveTab('permissions')} selected={activeTab === 'permissions'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'permissions' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'permissions' ? '#2563EB' : '#4B5563' }}>
                  <Icons.ShieldCheck size={18} style={{ marginRight: 10 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>Role Permissions Matrix</Typography>
                </ListItem>
                <ListItem button onClick={() => setActiveTab('passwords')} selected={activeTab === 'passwords'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'passwords' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'passwords' ? '#2563EB' : '#4B5563' }}>
                  <Icons.Lock size={18} style={{ marginRight: 10 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>Reset Passwords</Typography>
                </ListItem>
                <ListItem button onClick={() => setActiveTab('sheets')} selected={activeTab === 'sheets'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'sheets' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'sheets' ? '#2563EB' : '#4B5563' }}>
                  <Icons.FileSpreadsheet size={18} style={{ marginRight: 10 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>Google Sheets Config</Typography>
                </ListItem>
                 <ListItem button onClick={() => setActiveTab('rotation')} selected={activeTab === 'rotation'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'rotation' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'rotation' ? '#2563EB' : '#4B5563' }}>
                   <Icons.RefreshCw size={18} style={{ marginRight: 10 }} />
                   <Typography variant="body2" sx={{ fontWeight: 600 }}>Lead Rotation Engine</Typography>
                 </ListItem>
                   <ListItem button onClick={() => setActiveTab('templates')} selected={activeTab === 'templates'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'templates' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'templates' ? '#2563EB' : '#4B5563' }}>
                     <Icons.MessageSquare size={18} style={{ marginRight: 10 }} />
                     <Typography variant="body2" sx={{ fontWeight: 600 }}>Notification Templates</Typography>
                   </ListItem>
                   <ListItem button onClick={() => setActiveTab('sidebar_categories')} selected={activeTab === 'sidebar_categories'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'sidebar_categories' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'sidebar_categories' ? '#2563EB' : '#4B5563' }}>
                     <Icons.FolderTree size={18} style={{ marginRight: 10 }} />
                     <Typography variant="body2" sx={{ fontWeight: 600 }}>Sidebar Groups</Typography>
                   </ListItem>
                   <ListItem button onClick={() => setActiveTab('intake')} selected={activeTab === 'intake'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'intake' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'intake' ? '#2563EB' : '#4B5563' }}>
                     <Icons.KeyRound size={18} style={{ marginRight: 10 }} />
                     <Typography variant="body2" sx={{ fontWeight: 600 }}>Quick Add Intake Link</Typography>
                   </ListItem>
                   <ListItem button onClick={() => setActiveTab('whatsapp')} selected={activeTab === 'whatsapp'} sx={{ borderRadius: '8px', mb: 0.5, py: 1.5, backgroundColor: activeTab === 'whatsapp' ? 'rgba(37,99,235,0.08) !important' : 'transparent', color: activeTab === 'whatsapp' ? '#2563EB' : '#4B5563' }}>
                      <Icons.MessageCircle size={18} style={{ marginRight: 10 }} />
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>WhatsApp Integration</Typography>
                    </ListItem>
                  <Divider sx={{ my: 1 }} />
                  <ListItem 
                    button 
                    onClick={logout} 
                    sx={{ 
                      borderRadius: '8px', 
                      py: 1.5, 
                      color: '#EF4444', 
                      '&:hover': { backgroundColor: 'rgba(239, 68, 68, 0.08)' } 
                    }}
                  >
                    <Icons.LogOut size={18} style={{ marginRight: 10 }} />
                    <Typography variant="body2" sx={{ fontWeight: 700 }}>Log Out</Typography>
                  </ListItem>
                </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Settings Tab Contents */}
        <Grid item xs={12} md={9}>
          {statusMsg.text && (
            <Alert severity={statusMsg.type} onClose={() => setStatusMsg({ type: '', text: '' })} sx={{ mb: 3, borderRadius: '8px' }}>
              {statusMsg.text}
            </Alert>
          )}

          {/* TAB 1: FIELDS SCHEMA EDITOR */}
          {activeTab === 'fields' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={3.5}>
                  <Typography variant="h4" sx={{ fontWeight: 700, fontSize: '18px', fontFamily: 'Poppins' }}>
                    Configure Fields for Modules
                  </Typography>
                  <FormControl size="small" sx={{ width: 200 }}>
                    <InputLabel>Select Module</InputLabel>
                    <Select
                      label="Select Module"
                      value={selectedModule}
                      onChange={(e) => setSelectedModule(e.target.value)}
                    >
                      {Object.keys(metadata.modules).map(key => (
                        <MenuItem key={key} value={key}>{metadata.modules[key].label}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>

                <Divider sx={{ mb: 3 }} />

                {/* List Current Fields */}
                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>Active Fields in '{metadata.modules[selectedModule].label}' Schema</Typography>
                <TableContainer component={Paper} variant="outlined" sx={{ mb: 4, borderRadius: '8px', boxShadow: 'none' }}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ width: 40 }}></TableCell>
                        <TableCell sx={{ width: 70 }}>Order</TableCell>
                        <TableCell>Field Name (key)</TableCell>
                        <TableCell>Display Label</TableCell>
                        <TableCell>Data Type</TableCell>
                        <TableCell>Required</TableCell>
                        <TableCell>Show in Grid</TableCell>
                        <TableCell align="right">Action</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {metadata.modules[selectedModule].fields.map((f, index) => (
                        <TableRow 
                          key={f.name}
                          draggable
                          onDragStart={(e) => handleDragStart(e, index)}
                          onDragOver={(e) => handleDragOver(e, index)}
                          onDrop={(e) => handleDrop(e, index)}
                          onDragEnd={handleDragEnd}
                          sx={{ 
                            cursor: 'grab',
                            backgroundColor: draggedIndex === index ? 'rgba(37, 99, 235, 0.08) !important' : 'transparent',
                            opacity: draggedIndex === index ? 0.5 : 1,
                            '&:hover': { backgroundColor: '#F8FAFC' },
                            transition: 'opacity 0.15s, background-color 0.15s'
                          }}
                        >
                          <TableCell sx={{ width: 40, color: '#94A3B8', borderBottom: 'none', py: 1.5 }}>
                            <Icons.GripVertical size={16} style={{ cursor: 'grab' }} />
                          </TableCell>
                          <TableCell sx={{ width: 70, borderBottom: 'none' }}>
                            <TextField
                              size="small"
                              value={indexToAlphabet(index)}
                              onChange={(e) => handleAlphabetPositionChange(f.name, e.target.value)}
                              inputProps={{ 
                                style: { textAlign: 'center', padding: '4px 6px', textTransform: 'uppercase' } 
                              }}
                              sx={{ width: 55 }}
                            />
                          </TableCell>
                          <TableCell sx={{ fontWeight: 600 }}>{f.name}</TableCell>
                          <TableCell>{f.label}</TableCell>
                          <TableCell><Chip label={f.type} size="small" sx={{ height: 18, fontSize: '10px', textTransform: 'uppercase' }} /></TableCell>
                          <TableCell>
                            <Checkbox 
                              size="small"
                              checked={f.required || false}
                              disabled={f.name === 'id'}
                              onChange={async (e) => {
                                const updatedFields = [...metadata.modules[selectedModule].fields];
                                const fIdx = updatedFields.findIndex(field => field.name === f.name);
                                if (fIdx !== -1) {
                                  updatedFields[fIdx] = { ...f, required: e.target.checked };
                                  const updated = {
                                    ...metadata,
                                    modules: {
                                      ...metadata.modules,
                                      [selectedModule]: {
                                        ...metadata.modules[selectedModule],
                                        fields: updatedFields
                                      }
                                    }
                                  };
                                  await saveMetadata(updated);
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Checkbox 
                              size="small"
                              checked={f.showInTable !== false}
                              disabled={f.name === 'id'}
                              onChange={async (e) => {
                                const updatedFields = [...metadata.modules[selectedModule].fields];
                                const fIdx = updatedFields.findIndex(field => field.name === f.name);
                                if (fIdx !== -1) {
                                  updatedFields[fIdx] = { ...f, showInTable: e.target.checked };
                                  const updated = {
                                    ...metadata,
                                    modules: {
                                      ...metadata.modules,
                                      [selectedModule]: {
                                        ...metadata.modules[selectedModule],
                                        fields: updatedFields
                                      }
                                    }
                                  };
                                  await saveMetadata(updated);
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell align="right">
                            <IconButton 
                              size="small" 
                              onClick={() => handleMoveFieldUp(f.name)} 
                              disabled={index === 0}
                              sx={{ mr: 0.5 }}
                            >
                              <Icons.ChevronUp size={14} />
                            </IconButton>
                            <IconButton 
                              size="small" 
                              onClick={() => handleMoveFieldDown(f.name)} 
                              disabled={index === metadata.modules[selectedModule].fields.length - 1}
                              sx={{ mr: 1 }}
                            >
                              <Icons.ChevronDown size={14} />
                            </IconButton>
                            {f.name !== 'id' && (
                              <IconButton size="small" color="primary" onClick={() => handleStartEditField(f)} sx={{ mr: 1 }}>
                                <Icons.Pencil size={14} />
                              </IconButton>
                            )}
                            <IconButton size="small" color="error" onClick={() => handleDeleteField(f.name)}>
                              <Icons.Trash2 size={14} />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>

                <Divider sx={{ mb: 3 }} />

                {/* Add new field form */}
                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 2 }}>
                  {editingField ? `Edit Field Schema: ${editingField.name}` : 'Register Custom Field'}
                </Typography>
                <Box component="form" onSubmit={handleAddField}>
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <TextField 
                        label="Display Title (e.g. Near Landmark)" 
                        fullWidth
                        size="small"
                        value={newFieldLabel}
                        onChange={(e) => handleFieldLabelChange(e.target.value)}
                        required
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField 
                        label="Field API Name (lowercase, no spaces, e.g. landmark)" 
                        fullWidth
                        size="small"
                        value={newFieldName}
                        onChange={(e) => setNewFieldName(e.target.value)}
                        required
                        disabled={!!editingField}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Type</InputLabel>
                        <Select
                          label="Type"
                          value={newFieldType}
                          onChange={(e) => setNewFieldType(e.target.value)}
                        >
                          <MenuItem value="text">Text (short string)</MenuItem>
                          <MenuItem value="number">Number (float/int)</MenuItem>
                          <MenuItem value="date">Calendar Date</MenuItem>
                          <MenuItem value="select">Dropdown Chip (Select)</MenuItem>
                          <MenuItem value="textarea">Paragraph Box (textarea)</MenuItem>
                          <MenuItem value="ref">Relationship Lookup (Ref)</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>

                    {newFieldType === 'select' && (
                      <Grid item xs={6}>
                        <FormControl fullWidth size="small">
                          <InputLabel>Chips Dropdown Group</InputLabel>
                          <Select
                            label="Chips Dropdown Group"
                            value={newFieldChipGroup}
                            onChange={(e) => setNewFieldChipGroup(e.target.value)}
                          >
                            {Object.keys(metadata.chips).map(group => (
                              <MenuItem key={group} value={group}>{group}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Grid>
                    )}

                    {newFieldType === 'ref' && (
                      <Grid item xs={6}>
                        <FormControl fullWidth size="small">
                          <InputLabel>Reference Table Module</InputLabel>
                          <Select
                            label="Reference Table Module"
                            value={newFieldRefModule}
                            onChange={(e) => setNewFieldRefModule(e.target.value)}
                          >
                            {Object.keys(metadata.modules).map(mod => (
                              <MenuItem key={mod} value={mod}>{metadata.modules[mod].label}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Grid>
                    )}

                    <Grid item xs={6} display="flex" gap={2} alignItems="center">
                      <FormControlLabel
                        control={<Checkbox checked={newFieldRequired} onChange={(e)=>setNewFieldRequired(e.target.checked)} />}
                        label="Required validation"
                      />
                      <FormControlLabel
                        control={<Checkbox checked={newFieldShowTable} onChange={(e)=>setNewFieldShowTable(e.target.checked)} />}
                        label="Show in Table Grid"
                      />
                    </Grid>
                     <Grid item xs={12} display="flex" justifyContent="flex-end" gap={2}>
                       {editingField && (
                         <Button variant="outlined" onClick={handleCancelEditField} startIcon={<Icons.X size={16} />}>
                           Cancel
                         </Button>
                       )}
                       <Button type="submit" variant="contained" startIcon={editingField ? <Icons.Save size={16} /> : <Icons.Plus size={16} />}>
                         {editingField ? 'Update Field Schema' : 'Add Field Schema'}
                       </Button>
                     </Grid>
                  </Grid>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 2: CHIPS EDITOR */}
          {activeTab === 'chips' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={3.5}>
                  <Typography variant="h4" sx={{ fontWeight: 700, fontSize: '18px', fontFamily: 'Poppins' }}>
                    Configure Chip Dropdowns
                  </Typography>
                  <FormControl size="small" sx={{ width: 220 }}>
                    <InputLabel>Select Chip Category</InputLabel>
                    {(() => {
                      const grouped = {};
                      // 1. Scan metadata modules
                      Object.entries(metadata.modules || {}).forEach(([modKey, modConfig]) => {
                        const modLabel = modConfig.name || modKey;
                        const fields = modConfig.fields || [];
                        fields.forEach(f => {
                          if (f.chipGroup && metadata.chips[f.chipGroup]) {
                            if (!grouped[modLabel]) {
                              grouped[modLabel] = new Set();
                            }
                            grouped[modLabel].add(f.chipGroup);
                          }
                        });
                      });

                      // 2. Scan other sections in metadata or custom known lists
                      const specialModules = {
                        'Attendance & HR': ['attendanceStatus', 'leaveTypes', 'salaryStatus'],
                        'Dealer Management': ['dealerStatus', 'callOutcomes'],
                        'Properties & Inventory': ['propertyStatus', 'rci', 'zone', 'propertyFacing', 'propertyTransactionType', 'propertyAvailability', 'propertyApprovalStatus']
                      };

                      Object.entries(specialModules).forEach(([modLabel, groups]) => {
                        groups.forEach(g => {
                          if (metadata.chips[g]) {
                            if (!grouped[modLabel]) {
                              grouped[modLabel] = new Set();
                            }
                            grouped[modLabel].add(g);
                          }
                        });
                      });

                      const groupedGroups = new Set();
                      Object.values(grouped).forEach(set => {
                        set.forEach(g => groupedGroups.add(g));
                      });

                      const commonGroup = [];
                      Object.keys(metadata.chips || {}).forEach(group => {
                        if (!groupedGroups.has(group)) {
                          commonGroup.push(group);
                        }
                      });

                      const selectItems = [];
                      Object.entries(grouped).forEach(([modLabel, set]) => {
                        if (set.size > 0) {
                          selectItems.push(
                            <ListSubheader key={`header-${modLabel}`} sx={{ fontWeight: 800, color: '#1E293B', backgroundColor: '#F1F5F9', lineHeight: '32px' }}>
                              {String(modLabel).toUpperCase()}
                            </ListSubheader>
                          );
                          Array.from(set).sort().forEach(group => {
                            selectItems.push(
                              <MenuItem key={group} value={group} sx={{ pl: 3.5, fontWeight: 500 }}>
                                {group}
                              </MenuItem>
                            );
                          });
                        }
                      });

                      if (commonGroup.length > 0) {
                        selectItems.push(
                          <ListSubheader key="header-other" sx={{ fontWeight: 800, color: '#1E293B', backgroundColor: '#F1F5F9', lineHeight: '32px' }}>
                            OTHER DROPDOWNS
                          </ListSubheader>
                        );
                        commonGroup.sort().forEach(group => {
                          selectItems.push(
                            <MenuItem key={group} value={group} sx={{ pl: 3.5, fontWeight: 500 }}>
                              {group}
                            </MenuItem>
                          );
                        });
                      }

                      return (
                        <Select
                          label="Select Chip Category"
                          value={selectedChipGroup}
                          onChange={(e) => {
                            setSelectedChipGroup(e.target.value);
                            handleCancelEditChip();
                          }}
                          MenuProps={{
                            PaperProps: {
                              sx: {
                                maxHeight: 400,
                                borderRadius: '12px',
                                boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
                              }
                            }
                          }}
                        >
                          {selectItems}
                        </Select>
                      );
                    })()}
                  </FormControl>
                </Box>

                <Divider sx={{ mb: 3 }} />

                {/* List Current Chip Choices */}
                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>Available Chip values & Ordering</Typography>
                <Box sx={{ border: '1px solid #E2E8F0', borderRadius: '12px', overflow: 'hidden', mb: 4 }}>
                  <Table size="small">
                    <TableHead sx={{ backgroundColor: '#F8FAFC' }}>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 700 }}>Label / Preview</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Value Code</TableCell>
                        <TableCell sx={{ fontWeight: 700 }} align="center">Reorder</TableCell>
                        <TableCell sx={{ fontWeight: 700 }} align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {!metadata.chips[selectedChipGroup] || metadata.chips[selectedChipGroup].length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} align="center" sx={{ py: 3, color: '#94A3B8' }}>
                            No options listed for this category.
                          </TableCell>
                        </TableRow>
                      ) : (
                        metadata.chips[selectedChipGroup].map((chip, index) => (
                          <TableRow key={chip.value} hover>
                            <TableCell>
                              <Chip 
                                label={chip.label}
                                sx={{ 
                                  backgroundColor: `${chip.color}15`, 
                                  color: chip.color, 
                                  border: `1px solid ${chip.color}30`, 
                                  fontWeight: 700 
                                }}
                              />
                            </TableCell>
                            <TableCell sx={{ fontFamily: 'monospace', color: '#475569' }}>
                              {chip.value}
                            </TableCell>
                            <TableCell align="center">
                              <Box display="flex" justifyContent="center" gap={0.5}>
                                <IconButton 
                                  size="small" 
                                  disabled={index === 0} 
                                  onClick={() => handleShiftChip(selectedChipGroup, index, 'up')}
                                  sx={{ color: '#2563EB' }}
                                >
                                  <Icons.ArrowUp size={16} />
                                </IconButton>
                                <IconButton 
                                  size="small" 
                                  disabled={index === metadata.chips[selectedChipGroup].length - 1} 
                                  onClick={() => handleShiftChip(selectedChipGroup, index, 'down')}
                                  sx={{ color: '#2563EB' }}
                                >
                                  <Icons.ArrowDown size={16} />
                                </IconButton>
                              </Box>
                            </TableCell>
                            <TableCell align="right">
                              <Box display="flex" justifyContent="flex-end" gap={0.5}>
                                <IconButton 
                                  size="small" 
                                  color="primary" 
                                  onClick={() => handleStartEditChip(chip, index)}
                                >
                                  <Icons.Edit size={16} />
                                </IconButton>
                                <IconButton 
                                  size="small" 
                                  color="error" 
                                  onClick={() => handleDeleteChip(chip.value)}
                                >
                                  <Icons.Trash2 size={16} />
                                </IconButton>
                              </Box>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </Box>

                <Divider sx={{ mb: 3 }} />

                 <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 2 }}>
                   {editingChipIndex !== null ? 'Edit Dropdown Choice' : 'Add Dropdown Choice'}
                 </Typography>
                 <Box component="form" onSubmit={handleAddChip}>
                   <Grid container spacing={2}>
                     <Grid item xs={editingChipIndex !== null ? 4 : 4}>
                       <TextField 
                         label="Display Title (e.g. Dealer)" 
                         fullWidth
                         size="small"
                         value={newChipLabel}
                         onChange={(e)=>handleChipLabelChange(e.target.value)}
                         required
                       />
                     </Grid>
                     <Grid item xs={editingChipIndex !== null ? 3.5 : 4}>
                       <TextField 
                         label="API value (lowercase, no spaces, e.g. dealer)" 
                         fullWidth
                         size="small"
                         value={newChipVal}
                         onChange={(e)=>setNewChipVal(e.target.value)}
                         required
                       />
                     </Grid>
                     <Grid item xs={editingChipIndex !== null ? 2.5 : 3}>
                       <TextField 
                         type="color"
                         label="Chip Hex Color" 
                         fullWidth
                         size="small"
                         value={newChipColor}
                         onChange={(e)=>setNewChipColor(e.target.value)}
                       />
                     </Grid>
                     <Grid item xs={editingChipIndex !== null ? 2 : 1} display="flex" alignItems="flex-end" gap={1}>
                       <Button type="submit" variant="contained" fullWidth sx={{ height: 40, p: 0 }}>
                         {editingChipIndex !== null ? <Icons.Save size={18} /> : <Icons.Plus size={18} />}
                       </Button>
                       {editingChipIndex !== null && (
                         <Button variant="outlined" color="secondary" onClick={handleCancelEditChip} fullWidth sx={{ height: 40, p: 0 }}>
                           <Icons.X size={18} />
                         </Button>
                       )}
                     </Grid>
                   </Grid>
                 </Box>

                <Divider sx={{ my: 4 }} />

                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 2 }}>Register New Dropdown Category</Typography>
                <Box component="form" onSubmit={handleCreateCategory} sx={{ maxWidth: 500 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={8}>
                      <TextField 
                        label="Category Key Name (e.g. lead_sources)" 
                        fullWidth
                        size="small"
                        value={newCategoryName}
                        onChange={(e)=>setNewCategoryName(e.target.value)}
                        placeholder="lowercase_with_underscores"
                        required
                      />
                    </Grid>
                    <Grid item xs={4} display="flex" alignItems="flex-end">
                      <Button type="submit" variant="contained" fullWidth sx={{ height: 40 }} startIcon={<Icons.Plus size={16} />}>
                        Create Category
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 3: ROLE PERMISSIONS MATRIX */}
          {activeTab === 'permissions' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h4" sx={{ fontWeight: 700, fontSize: '18px', mb: 1, fontFamily: 'Poppins' }}>
                  Role Permission matrix
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                  Configure module access permissions (View, Create, Edit, Delete, Export) per security role.
                </Typography>

                <Divider sx={{ mb: 3 }} />

                <TableContainer component={Paper} sx={{ border: '1px solid #E2E8F0', boxShadow: 'none' }}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ fontWeight: 600 }}>Module Target</TableCell>
                        {Object.keys(metadata.rolesPermissions).map(role => (
                          <TableCell key={role} align="center" sx={{ fontWeight: 600 }}>{role}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.keys(metadata.modules).map(moduleKey => (
                        <TableRow key={moduleKey}>
                          <TableCell sx={{ fontWeight: 600 }}>{metadata.modules[moduleKey].label}</TableCell>
                          
                          {Object.keys(metadata.rolesPermissions).map(role => {
                            const hasView = (metadata.rolesPermissions[role][moduleKey] || []).includes('view');
                            const hasCreate = (metadata.rolesPermissions[role][moduleKey] || []).includes('create');
                            const hasEdit = (metadata.rolesPermissions[role][moduleKey] || []).includes('edit');
                            const hasDelete = (metadata.rolesPermissions[role][moduleKey] || []).includes('delete');
                            const hasExport = (metadata.rolesPermissions[role][moduleKey] || []).includes('export');

                            return (
                              <TableCell key={role} align="center">
                                <Box display="flex" flexDirection="column" gap={0.5} alignItems="center">
                                  <FormControlLabel
                                    control={
                                      <Checkbox 
                                        size="small" 
                                        checked={hasView} 
                                        onChange={() => handlePermissionToggle(role, moduleKey, 'view')} 
                                      />
                                    }
                                    label={<span style={{ fontSize: '10px', fontWeight: 600 }}>View</span>}
                                    sx={{ m: 0 }}
                                  />
                                  <FormControlLabel
                                    control={
                                      <Checkbox 
                                        size="small" 
                                        checked={hasCreate} 
                                        onChange={() => handlePermissionToggle(role, moduleKey, 'create')} 
                                      />
                                    }
                                    label={<span style={{ fontSize: '10px', fontWeight: 600 }}>Create</span>}
                                    sx={{ m: 0 }}
                                  />
                                  <FormControlLabel
                                    control={
                                      <Checkbox 
                                        size="small" 
                                        checked={hasEdit} 
                                        onChange={() => handlePermissionToggle(role, moduleKey, 'edit')} 
                                      />
                                    }
                                    label={<span style={{ fontSize: '10px', fontWeight: 600 }}>Edit</span>}
                                    sx={{ m: 0 }}
                                  />
                                  <FormControlLabel
                                    control={
                                      <Checkbox 
                                        size="small" 
                                        checked={hasDelete} 
                                        onChange={() => handlePermissionToggle(role, moduleKey, 'delete')} 
                                      />
                                    }
                                    label={<span style={{ fontSize: '10px', fontWeight: 600 }}>Delete</span>}
                                    sx={{ m: 0 }}
                                  />
                                </Box>
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>

                {/* Individual Employee Permissions Override section */}
                <Box sx={{ mt: 5 }}>
                  <Typography variant="h5" sx={{ fontWeight: 700, fontSize: '16px', mb: 1, fontFamily: 'Poppins' }}>
                    Individual Employee Permissions (Overrides)
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                    Set custom access controls for a specific employee by name. Overrides their default role settings.
                  </Typography>

                  <Grid container spacing={3} sx={{ mb: 3 }}>
                    <Grid item xs={12} sm={6}>
                      <FormControl size="small" fullWidth>
                        <InputLabel>Select Employee</InputLabel>
                        <Select
                          label="Select Employee"
                          value={selectedUserForPerms}
                          onChange={(e) => setSelectedUserForPerms(e.target.value)}
                        >
                          <MenuItem value=""><em>None selected</em></MenuItem>
                          {(moduleData.employees || []).filter(e => e.role !== 'Admin').map(emp => (
                            <MenuItem key={emp.id} value={emp.id}>
                              {emp.name} ({emp.id} • {emp.role || 'Staff'})
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    {selectedUserForPerms && metadata?.userPermissions?.[selectedUserForPerms] && (
                      <Grid item xs={12} sm={6}>
                        <Button 
                          variant="outlined" 
                          color="error" 
                          size="small"
                          onClick={() => handleResetUserPermissions(selectedUserForPerms)}
                          sx={{ textTransform: 'none', fontWeight: 600 }}
                        >
                          Reset User Permissions Override
                        </Button>
                      </Grid>
                    )}
                  </Grid>

                  {selectedUserForPerms && (() => {
                    const empObj = (moduleData.employees || []).find(e => e.id === selectedUserForPerms);
                    const userRole = empObj?.role || 'Employee';
                    
                    // User perms or fallback display of role perms
                    const userHasOverride = Boolean(metadata?.userPermissions?.[selectedUserForPerms]);
                    const currentPerms = metadata?.userPermissions?.[selectedUserForPerms] || metadata?.rolesPermissions?.[userRole] || {};

                    return (
                      <Box>
                        {!userHasOverride && (
                          <Alert severity="info" sx={{ mb: 2, fontSize: '12px' }}>
                            Currently showing default role permissions for <strong>{userRole}</strong>. Interacting with checkboxes will automatically create a custom override for <strong>{empObj?.name}</strong>.
                          </Alert>
                        )}
                        <TableContainer component={Paper} sx={{ border: '1px solid #E2E8F0', boxShadow: 'none' }}>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell sx={{ fontWeight: 600 }}>Module Target</TableCell>
                                <TableCell align="center" sx={{ fontWeight: 600 }}>View</TableCell>
                                <TableCell align="center" sx={{ fontWeight: 600 }}>Create</TableCell>
                                <TableCell align="center" sx={{ fontWeight: 600 }}>Edit</TableCell>
                                <TableCell align="center" sx={{ fontWeight: 600 }}>Delete</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {Object.keys(metadata.modules).map(moduleKey => {
                                const hasView = (currentPerms[moduleKey] || []).includes('view');
                                const hasCreate = (currentPerms[moduleKey] || []).includes('create');
                                const hasEdit = (currentPerms[moduleKey] || []).includes('edit');
                                const hasDelete = (currentPerms[moduleKey] || []).includes('delete');

                                return (
                                  <TableRow key={moduleKey}>
                                    <TableCell sx={{ fontWeight: 600 }}>{metadata.modules[moduleKey].label}</TableCell>
                                    <TableCell align="center">
                                      <Checkbox 
                                        size="small" 
                                        checked={hasView} 
                                        onChange={() => handleUserPermissionToggle(selectedUserForPerms, moduleKey, 'view')} 
                                      />
                                    </TableCell>
                                    <TableCell align="center">
                                      <Checkbox 
                                        size="small" 
                                        checked={hasCreate} 
                                        onChange={() => handleUserPermissionToggle(selectedUserForPerms, moduleKey, 'create')} 
                                      />
                                    </TableCell>
                                    <TableCell align="center">
                                      <Checkbox 
                                        size="small" 
                                        checked={hasEdit} 
                                        onChange={() => handleUserPermissionToggle(selectedUserForPerms, moduleKey, 'edit')} 
                                      />
                                    </TableCell>
                                    <TableCell align="center">
                                      <Checkbox 
                                        size="small" 
                                        checked={hasDelete} 
                                        onChange={() => handleUserPermissionToggle(selectedUserForPerms, moduleKey, 'delete')} 
                                      />
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Box>
                    );
                  })()}

                  {selectedUserForPerms && (
                    <Box sx={{ mt: 4, p: 3, border: '1px solid #E2E8F0', borderRadius: '12px', backgroundColor: '#F8FAFC' }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#0F172A', fontFamily: 'Poppins' }}>
                        Custom Column (Field) Permissions for {(moduleData.employees || []).find(e => String(e.id) === String(selectedUserForPerms))?.name}
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                        Check columns to allow this employee to view and edit them. Uncheck to hide them.
                      </Typography>

                      <FormControl size="small" sx={{ mb: 3, minWidth: 200 }}>
                        <InputLabel>Select Module</InputLabel>
                        <Select
                          label="Select Module"
                          value={userPermSelectedModule || 'leads'}
                          onChange={(e) => setUserPermSelectedModule(e.target.value)}
                        >
                          {Object.keys(metadata.modules).map(key => (
                            <MenuItem key={key} value={key}>{metadata.modules[key].label}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>

                      <Grid container spacing={2}>
                        {metadata.modules[userPermSelectedModule || 'leads'].fields.map(field => {
                          const userOverriden = metadata.userColumnPermissions?.[selectedUserForPerms]?.[userPermSelectedModule || 'leads']?.[field.name];
                          const isChecked = userOverriden !== undefined ? userOverriden.includes('view') : true;

                          return (
                            <Grid item xs={12} sm={6} md={4} key={field.name}>
                              <FormControlLabel
                                control={
                                  <Checkbox
                                    checked={isChecked}
                                    onChange={() => handleUserColumnPermissionToggle(selectedUserForPerms, userPermSelectedModule || 'leads', field.name, 'view')}
                                    sx={{ '&.Mui-checked': { color: '#2563EB' } }}
                                  />
                                }
                                label={field.label}
                              />
                            </Grid>
                          );
                        })}
                      </Grid>
                    </Box>
                  )}
                </Box>

                <Box sx={{ mt: 5 }}>
                  <Typography variant="h5" sx={{ fontWeight: 700, fontSize: '16px', mb: 1, fontFamily: 'Poppins' }}>
                    Field-Level Column Permissions (FLAC)
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                    Control which database fields (columns) are visible/editable to security roles. Check to allow, uncheck to hide.
                  </Typography>

                  <Divider sx={{ mb: 3 }} />

                  <Grid container spacing={3} sx={{ mb: 3 }}>
                    <Grid item xs={12} sm={6}>
                      <FormControl size="small" fullWidth>
                        <InputLabel>Select Target Role</InputLabel>
                        <Select
                          label="Select Target Role"
                          value={permSelectedRole}
                          onChange={(e) => setPermSelectedRole(e.target.value)}
                        >
                          {Object.keys(metadata.rolesPermissions).filter(r => r !== 'Admin').map(role => (
                            <MenuItem key={role} value={role}>{role}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <FormControl size="small" fullWidth>
                        <InputLabel>Select Module</InputLabel>
                        <Select
                          label="Select Module"
                          value={permSelectedModule}
                          onChange={(e) => setPermSelectedModule(e.target.value)}
                        >
                          {Object.keys(metadata.modules).map(key => (
                            <MenuItem key={key} value={key}>{metadata.modules[key].label}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>

                  <Box sx={{ border: '1px solid #E2E8F0', borderRadius: '12px', p: 3, backgroundColor: '#F8FAFC' }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 2 }}>
                      Visible Columns in '{metadata.modules[permSelectedModule].label}' for '{permSelectedRole}'
                    </Typography>
                    <Grid container spacing={2}>
                      {metadata.modules[permSelectedModule].fields.map(field => {
                        const allowedList = metadata.fieldPermissions?.[permSelectedRole]?.[permSelectedModule];
                        const isChecked = allowedList ? allowedList.includes(field.name) : true;

                        return (
                          <Grid item xs={12} sm={6} md={4} key={field.name}>
                            <FormControlLabel
                              control={
                                <Checkbox
                                  checked={isChecked}
                                  onChange={() => handleFieldPermissionToggle(permSelectedRole, permSelectedModule, field.name)}
                                  sx={{ '&.Mui-checked': { color: '#2563EB' } }}
                                />
                              }
                              label={
                                <Box>
                                  <Typography variant="body2" sx={{ fontWeight: 600, color: '#1E293B' }}>{field.label}</Typography>
                                  <Typography variant="caption" sx={{ color: '#64748B' }}>API: {field.name}</Typography>
                                </Box>
                              }
                            />
                          </Grid>
                        );
                      })}
                    </Grid>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 5: RESET PASSWORDS CONTROL */}
          {activeTab === 'passwords' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Reset Password Profile
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                  Quickly set or reset the secure login password for any employee account.
                </Typography>
                
                <Box component="form" onSubmit={handleUpdatePassword}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Select Employee</InputLabel>
                        <Select
                          value={passwordSelectedEmp}
                          onChange={(e) => setPasswordSelectedEmp(e.target.value)}
                          label="Select Employee"
                        >
                          {(moduleData.employees || []).map(emp => (
                            <MenuItem key={emp.id} value={emp.id}>{emp.name} ({emp.id})</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        size="small"
                        type="password"
                        label="New Login Password"
                        value={newPasswordVal}
                        onChange={(e) => setNewPasswordVal(e.target.value)}
                        fullWidth
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        size="small"
                        type="password"
                        label="Confirm Password"
                        value={confirmPasswordVal}
                        onChange={(e) => setConfirmPasswordVal(e.target.value)}
                        fullWidth
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ p: 1, border: '1px solid #E2E8F0', borderRadius: '8px', backgroundColor: '#F8FAFC' }}>
                        <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5, color: '#475569' }}>
                          Password Requirements:
                        </Typography>
                        <ul style={{ margin: 0, paddingLeft: 16, fontSize: '11px', color: '#64748B' }}>
                          <li>At least 8 characters long</li>
                          <li>Contains uppercase & lowercase letter</li>
                          <li>Contains at least one number</li>
                          <li>Contains one special character</li>
                        </ul>
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <Button 
                        type="submit" 
                        variant="contained" 
                        sx={{ backgroundColor: '#2563EB', '&:hover': { backgroundColor: '#1D4ED8' } }}
                      >
                        Update Login Password
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 5: GOOGLE SHEETS CONFIG */}
          {activeTab === 'sheets' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Google Sheets Integration Config
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                  Configure synchronization between your CRM database and Google Sheets.
                </Typography>

                <form onSubmit={handleSaveSheetsConfig}>
                  <Grid container spacing={3}>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={sheetsActive}
                            onChange={(e) => setSheetsActive(e.target.checked)}
                            color="primary"
                          />
                        }
                        label={
                          <Box>
                            <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                              Enable Active Sheets Synchronization
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#64748B' }}>
                              Automatically push database updates to Google Sheets in real time.
                            </Typography>
                          </Box>
                        }
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        label="Google Spreadsheet ID"
                        value={sheetsId}
                        onChange={(e) => setSheetsId(e.target.value)}
                        fullWidth
                        helperText="The unique ID from your Google Sheets URL: docs.google.com/spreadsheets/d/[SPREADSHEET_ID]/edit"
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        label="Google Service Account Email Address"
                        value={sheetsEmail}
                        onChange={(e) => setSheetsEmail(e.target.value)}
                        fullWidth
                        helperText="The client email address of your Google Cloud service account."
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        label="Google Service Account Private Key (PEM format)"
                        value={sheetsKey}
                        onChange={(e) => setSheetsKey(e.target.value)}
                        multiline
                        rows={6}
                        fullWidth
                        helperText="The complete private key string, including the BEGIN and END PRIVATE KEY markers."
                      />
                    </Grid>
                  </Grid>

                  <Divider sx={{ my: 3 }} />

                  <Box sx={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
                    <Box sx={{ display: 'flex', gap: 1.5 }}>
                      <Button
                        variant="outlined"
                        color="secondary"
                        onClick={handleTestSheets}
                        disabled={syncLoading}
                        startIcon={syncLoading ? <CircularProgress size={16} /> : <Icons.Zap size={16} />}
                        sx={{ borderRadius: '8px', textTransform: 'none', fontWeight: 600 }}
                      >
                        Test Connection
                      </Button>
                      <Button
                        variant="outlined"
                        color="primary"
                        onClick={handleSyncNow}
                        disabled={syncLoading}
                        startIcon={syncLoading ? <CircularProgress size={16} /> : <Icons.RefreshCw size={16} />}
                        sx={{ borderRadius: '8px', textTransform: 'none', fontWeight: 600 }}
                      >
                        Force Sync Now
                      </Button>
                    </Box>
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      sx={{ backgroundColor: '#2563EB', '&:hover': { backgroundColor: '#1D4ED8' }, borderRadius: '8px', px: 4, py: 1, textTransform: 'none', fontWeight: 700 }}
                    >
                      Save Configuration
                    </Button>
                  </Box>
                </form>
              </CardContent>
            </Card>
          )}

          {/* TAB 6: AUTO LEAD ROTATION ENGINE */}
          {activeTab === 'rotation' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Auto Lead Rotation Engine
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                  Reassign leads automatically when assigned representatives do not record any follow-up actions within the specified timeframe.
                </Typography>
                
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={rotationActive}
                          onChange={(e) => setRotationActive(e.target.checked)}
                          color="primary"
                        />
                      }
                      label={
                        <Box>
                          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                            Enable Automated Lead Rotation
                          </Typography>
                          <Typography variant="caption" sx={{ color: '#64748B' }}>
                            Leads will cycle to other active sales representatives if they remain untouched.
                          </Typography>
                        </Box>
                      }
                    />
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Inactivity Reassignment Limit (Hours)"
                      type="number"
                      value={rotationHours}
                      onChange={(e) => setRotationHours(e.target.value)}
                      fullWidth
                      disabled={!rotationActive}
                      placeholder="e.g. 24"
                      InputProps={{ inputProps: { min: 0.1, step: 0.1 } }}
                      helperText="Leads untouched for this length of time will rotate round-robin to the next sales agent."
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>
                      Rotate Leads from these Sources:
                    </Typography>
                    <Grid container spacing={1}>
                      {(metadata.chips.leadSources || []).map(source => {
                        const isChecked = rotatedSources.includes(source.value);
                        return (
                          <Grid item xs={6} sm={4} key={source.value}>
                            <FormControlLabel
                              control={
                                <Checkbox
                                  checked={isChecked}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setRotatedSources(prev => [...prev, source.value]);
                                    } else {
                                      setRotatedSources(prev => prev.filter(s => s !== source.value));
                                    }
                                  }}
                                  disabled={!rotationActive}
                                  color="primary"
                                />
                              }
                              label={source.label}
                            />
                          </Grid>
                        );
                      })}
                    </Grid>
                    <Typography variant="caption" sx={{ color: '#64748B', display: 'block', mt: 1 }}>
                      If no sources are checked, all lead sources will cycle by default.
                    </Typography>
                  </Grid>
                </Grid>

                <Divider sx={{ my: 3 }} />

                <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSaveRotationSettings}
                    sx={{ backgroundColor: '#2563EB', '&:hover': { backgroundColor: '#1D4ED8' }, borderRadius: '8px', px: 4, py: 1, textTransform: 'none', fontWeight: 700 }}
                  >
                    Save Rotation Settings
                  </Button>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 7: MESSAGE TEMPLATES CONFIG */}
          {activeTab === 'templates' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Configure Message Templates
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                  Set up default message templates for client follow-ups. You can use placeholder tags like: <strong>[Client Name]</strong>, <strong>[Property Name]</strong>, <strong>[Price]</strong>, <strong>[Locality]</strong>, <strong>[Sector]</strong>.
                </Typography>
                
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <TextField
                      label="WhatsApp Notification Template"
                      multiline
                      rows={3}
                      value={whatsappTemplate}
                      onChange={(e) => setWhatsappTemplate(e.target.value)}
                      fullWidth
                    />
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Email Subject Template"
                      value={emailSubjectTemplate}
                      onChange={(e) => setEmailSubjectTemplate(e.target.value)}
                      fullWidth
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="Email Body Template"
                      multiline
                      rows={5}
                      value={emailBodyTemplate}
                      onChange={(e) => setEmailBodyTemplate(e.target.value)}
                      fullWidth
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="SMS Notification Template"
                      multiline
                      rows={2}
                      value={smsTemplate}
                      onChange={(e) => setSmsTemplate(e.target.value)}
                      fullWidth
                    />
                  </Grid>
                </Grid>

                <Divider sx={{ my: 3 }} />

                <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSaveTemplates}
                    sx={{ backgroundColor: '#2563EB', '&:hover': { backgroundColor: '#1D4ED8' }, borderRadius: '8px', px: 4, py: 1, textTransform: 'none', fontWeight: 700 }}
                  >
                    Save Templates
                  </Button>
                </Box>
              </CardContent>
            </Card>
          )}

          {/* TAB 8: SIDEBAR CATEGORIES CONFIG */}
          {activeTab === 'sidebar_categories' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Sidebar Groups & Module Categorization
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 4 }}>
                  Organize modules in the sidebar under custom group headers. Uncategorized modules will dynamically show up at the bottom.
                </Typography>

                {/* Add Category Form */}
                <Box component="form" onSubmit={handleAddSidebarCategory} sx={{ mb: 4, display: 'flex', gap: 2, alignItems: 'flex-start' }}>
                  <TextField
                    label="New Sidebar Group Name"
                    size="small"
                    value={sidebarCategoryInputName}
                    onChange={(e) => setSidebarCategoryInputName(e.target.value)}
                    sx={{ flexGrow: 1 }}
                    placeholder="e.g. Finance, Core Sales, Inventory"
                  />
                  <Button
                    type="submit"
                    variant="contained"
                    startIcon={<Icons.Plus size={16} />}
                    sx={{ backgroundColor: '#2563EB', '&:hover': { backgroundColor: '#1D4ED8' }, borderRadius: '8px', px: 3, py: 1.1, textTransform: 'none', fontWeight: 700 }}
                  >
                    Add Group
                  </Button>
                </Box>

                <Divider sx={{ my: 3 }} />

                {/* Categories Reorder and Management List */}
                <Typography variant="subtitle1" sx={{ fontWeight: 800, mb: 2, fontFamily: 'Poppins' }}>
                  Sidebar Layout Categories ({(metadata.sidebarCategories || []).length})
                </Typography>

                <Grid container spacing={3}>
                  <Grid item xs={12} md={7}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                      {(metadata.sidebarCategories || []).map((cat, idx) => (
                        <Paper
                          key={cat.id}
                          variant="outlined"
                          sx={{
                            p: 2.5,
                            borderRadius: '12px',
                            borderColor: '#E2E8F0',
                            backgroundColor: '#F8FAFC'
                          }}
                        >
                          {/* Category Header Controls */}
                          <Box display="flex" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
                            {sidebarEditingCategoryId === cat.id ? (
                              <Box display="flex" gap={1} alignItems="center" sx={{ flexGrow: 1 }}>
                                <TextField
                                  size="small"
                                  value={sidebarEditingCategoryLabel}
                                  onChange={(e) => setSidebarEditingCategoryLabel(e.target.value)}
                                  autoFocus
                                />
                                <IconButton size="small" color="primary" onClick={() => handleRenameSidebarCategory(cat.id)}>
                                  <Icons.Check size={18} />
                                </IconButton>
                                <IconButton size="small" onClick={() => setSidebarEditingCategoryId('')}>
                                  <Icons.X size={18} />
                                </IconButton>
                              </Box>
                            ) : (
                              <Box display="flex" alignItems="center" gap={1}>
                                <Typography variant="subtitle2" sx={{ fontWeight: 800, color: '#0F172A', fontSize: '15px' }}>
                                  {cat.label}
                                </Typography>
                                <Typography variant="caption" sx={{ color: '#94A3B8' }}>
                                  ({cat.id})
                                </Typography>
                                <IconButton
                                  size="small"
                                  onClick={() => {
                                    setSidebarEditingCategoryId(cat.id);
                                    setSidebarEditingCategoryLabel(cat.label);
                                  }}
                                  sx={{ color: '#64748B', p: 0.5 }}
                                >
                                  <Icons.Edit3 size={14} />
                                </IconButton>
                              </Box>
                            )}

                            {/* Reorder and Delete Actions */}
                            <Box display="flex" gap={0.5}>
                              <IconButton
                                size="small"
                                disabled={idx === 0}
                                onClick={() => handleReorderSidebarCategory(cat.id, 'up')}
                              >
                                <Icons.ArrowUp size={16} />
                              </IconButton>
                              <IconButton
                                size="small"
                                disabled={idx === (metadata.sidebarCategories || []).length - 1}
                                onClick={() => handleReorderSidebarCategory(cat.id, 'down')}
                              >
                                <Icons.ArrowDown size={16} />
                              </IconButton>
                              <IconButton
                                size="small"
                                color="error"
                                onClick={() => handleDeleteSidebarCategory(cat.id)}
                              >
                                <Icons.Trash2 size={16} />
                              </IconButton>
                            </Box>
                          </Box>

                          {/* List of Modules in Category */}
                          {cat.modules && cat.modules.length > 0 ? (
                            <Box display="flex" flexWrap="wrap" gap={1}>
                              {cat.modules.map(modKey => {
                                const m = metadata.modules[modKey];
                                if (!m) return null;
                                return (
                                  <Chip
                                    key={modKey}
                                    label={m.label}
                                    sx={{ fontWeight: 700, backgroundColor: 'white', border: '1px solid #E2E8F0' }}
                                    onDelete={() => handleMoveSidebarModule(modKey, '')}
                                  />
                                );
                              })}
                            </Box>
                          ) : (
                            <Typography variant="body2" sx={{ color: '#94A3B8', fontSize: '12px', fontStyle: 'italic' }}>
                              No modules assigned to this category.
                            </Typography>
                          )}
                        </Paper>
                      ))}
                    </Box>
                  </Grid>

                  {/* Modules Assignment Board */}
                  <Grid item xs={12} md={5}>
                    <Paper variant="outlined" sx={{ p: 2.5, borderRadius: '12px', borderColor: '#E2E8F0' }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 800, mb: 1.5, fontFamily: 'Poppins' }}>
                        Module Assignments
                      </Typography>
                      <Typography variant="caption" sx={{ color: '#64748B', display: 'block', mb: 2 }}>
                        Assign any module to a specific sidebar group using the dropdown.
                      </Typography>

                      <Box display="flex" flexDirection="column" gap={1.5}>
                        {Object.keys(metadata.modules).map(modKey => {
                          const m = metadata.modules[modKey];
                          const activeCat = (metadata.sidebarCategories || []).find(c => (c.modules || []).includes(modKey))?.id || '';
                          return (
                            <Box
                              key={modKey}
                              display="flex"
                              justifyContent="space-between"
                              alignItems="center"
                              sx={{
                                py: 1,
                                px: 1.5,
                                border: '1px solid #F1F5F9',
                                borderRadius: '8px',
                                backgroundColor: '#F8FAFC'
                              }}
                            >
                              <Box display="flex" alignItems="center" gap={1}>
                                <Icons.Layers size={16} color="#64748B" />
                                <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '13px' }}>
                                  {m.label}
                                </Typography>
                              </Box>

                              <FormControl size="small" sx={{ minWidth: 140 }}>
                                <Select
                                  value={activeCat}
                                  onChange={(e) => handleMoveSidebarModule(modKey, e.target.value)}
                                  displayEmpty
                                  sx={{ fontSize: '12px', fontWeight: 600, backgroundColor: 'white' }}
                                >
                                  <MenuItem value="" sx={{ fontSize: '12px' }}>
                                    <em>Uncategorized</em>
                                  </MenuItem>
                                  {(metadata.sidebarCategories || []).map(cat => (
                                    <MenuItem key={cat.id} value={cat.id} sx={{ fontSize: '12px' }}>
                                      {cat.label}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </Box>
                          );
                        })}
                      </Box>
                    </Paper>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          )}

          {/* TAB 9: QUICK ADD INTAKE LINK */}
          {activeTab === 'intake' && (
            <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '20px', fontFamily: 'Poppins', mb: 1 }}>
                  Expiring Quick Add Intake Registration Link
                </Typography>
                <Typography variant="body2" sx={{ color: '#64748B', mb: 4 }}>
                  Generate a temporary, expiring signed access link to allow external users or devices to submit new records (Leads, Customers, Properties, or Queries) via the Quick Add portal without requiring a full CRM user login.
                </Typography>

                {intakeError && (
                  <Alert severity="error" sx={{ mb: 3, borderRadius: '12px' }}>
                    {intakeError}
                  </Alert>
                )}

                <Box sx={{ mb: 4 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleGenerateIntakeLink}
                    disabled={intakeLoading}
                    startIcon={intakeLoading ? <CircularProgress size={16} color="inherit" /> : <Icons.KeyRound size={16} />}
                    sx={{ textTransform: 'none', borderRadius: '8px', fontWeight: 600 }}
                  >
                    {intakeLoading ? 'Generating...' : 'Generate New 24-Hour Link'}
                  </Button>
                </Box>

                {intakeToken && (
                  <Box sx={{ mt: 3 }}>
                    <Typography variant="body2" sx={{ fontWeight: 700, mb: 1, color: '#1E293B' }}>
                      Expiring Intake Link:
                    </Typography>
                    <Grid container spacing={1} alignItems="stretch">
                      <Grid item xs={10}>
                        <TextField
                          fullWidth
                          size="small"
                          InputProps={{ readOnly: true }}
                          value={`${window.location.origin}/quick-add?token=${intakeToken}`}
                          sx={{
                            backgroundColor: '#F8FAFC',
                            '& .MuiInputBase-input': { fontFamily: 'monospace', fontSize: '12px' }
                          }}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Button
                          fullWidth
                          variant="outlined"
                          onClick={() => {
                            navigator.clipboard.writeText(`${window.location.origin}/quick-add?token=${intakeToken}`);
                            alert('Intake link copied to clipboard!');
                          }}
                          sx={{ textTransform: 'none', height: '100%', borderRadius: '8px', fontWeight: 600 }}
                        >
                          Copy
                        </Button>
                      </Grid>
                    </Grid>
                    <Typography variant="caption" sx={{ display: 'block', mt: 1.5, color: '#EF4444', fontWeight: 600 }}>
                      ⚠️ Security Notice: This link gives direct registration access and will expire automatically in exactly 24 hours.
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          )}

          {/* TAB 10: WHATSAPP INTEGRATION & BROADCASTS */}
          {activeTab === 'whatsapp' && (
            <Grid container spacing={3}>
              {/* Left Column: API Configuration & Templates */}
              <Grid item xs={12} md={5}>
                {/* 1. API Config Card */}
                <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px', mb: 3 }}>
                  <CardContent sx={{ p: 3 }}>
                    <Box display="flex" alignItems="center" gap={1.5} mb={2}>
                      <Icons.Settings size={22} color="#2563EB" />
                      <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '18px', fontFamily: 'Poppins' }}>
                        API Gateway Settings
                      </Typography>
                    </Box>
                    <Typography variant="body2" sx={{ color: '#64748B', mb: 3 }}>
                      Integrate your CRM with WhatsApp using instance-based API providers or Meta's official cloud API.
                    </Typography>

                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <FormControl fullWidth size="small">
                          <InputLabel>Select Gateway / Provider</InputLabel>
                          <Select
                            value={waGateway}
                            onChange={(e) => setWaGateway(e.target.value)}
                            label="Select Gateway / Provider"
                          >
                            <MenuItem value="Simulator">Simulated / Test Gateway</MenuItem>
                            <MenuItem value="UltraMsg">UltraMsg API Gateway</MenuItem>
                            <MenuItem value="Wassenger">Wassenger API Gateway</MenuItem>
                            <MenuItem value="Meta Cloud API">Meta WhatsApp Cloud API</MenuItem>
                            <MenuItem value="Custom API">Custom API Gateway</MenuItem>
                          </Select>
                        </FormControl>
                      </Grid>

                      {waGateway !== 'Simulator' && (
                        <>
                          <Grid item xs={12}>
                            <TextField
                              fullWidth
                              size="small"
                              label={waGateway === 'Custom API' ? 'Authorization Header / Token' : 'API Key / Access Token'}
                              type="password"
                              value={waApiKey}
                              onChange={(e) => setWaApiKey(e.target.value)}
                            />
                          </Grid>
                          <Grid item xs={12}>
                            <TextField
                              fullWidth
                              size="small"
                              label={waGateway === 'Custom API' ? 'Custom API Request URL' : 'Instance ID / Phone Number ID'}
                              value={waInstanceId}
                              onChange={(e) => setWaInstanceId(e.target.value)}
                            />
                          </Grid>
                          {waGateway !== 'Custom API' && (
                            <Grid item xs={12}>
                              <TextField
                                fullWidth
                                size="small"
                                label="Sender Phone Number"
                                placeholder="+919999999999"
                                value={waSenderNumber}
                                onChange={(e) => setWaSenderNumber(e.target.value)}
                              />
                            </Grid>
                          )}
                        </>
                      )}

                      <Grid item xs={12}>
                        <Button
                          variant="contained"
                          color="primary"
                          fullWidth
                          onClick={handleSaveWaConfig}
                          sx={{ textTransform: 'none', borderRadius: '8px', fontWeight: 600, mt: 1 }}
                        >
                          Save Connection Configuration
                        </Button>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>

                {/* 2. Message Templates Manager Card */}
                <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px' }}>
                  <CardContent sx={{ p: 3 }}>
                    <Box display="flex" alignItems="center" gap={1.5} mb={2}>
                      <Icons.MessageSquare size={22} color="#2563EB" />
                      <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '18px', fontFamily: 'Poppins' }}>
                        WhatsApp Templates
                      </Typography>
                    </Box>
                    
                    {/* Add new template */}
                    <Box sx={{ mb: 3, p: 2, border: '1px dashed #CBD5E1', borderRadius: '12px', backgroundColor: '#F8FAFC' }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5, color: '#1E293B' }}>
                        Create New Template
                      </Typography>
                      <Grid container spacing={1.5}>
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            size="small"
                            label="Template Name"
                            value={newTemplateName}
                            onChange={(e) => setNewTemplateName(e.target.value)}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            size="small"
                            multiline
                            rows={3}
                            label="Template Body"
                            placeholder="Use placeholders like [Client Name], [Property Name], [Price]"
                            value={newTemplateBody}
                            onChange={(e) => setNewTemplateBody(e.target.value)}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Button
                            variant="outlined"
                            size="small"
                            fullWidth
                            startIcon={<Icons.Plus size={16} />}
                            onClick={handleAddWaTemplate}
                            sx={{ textTransform: 'none', borderRadius: '6px', fontWeight: 600 }}
                          >
                            Create Template
                          </Button>
                        </Grid>
                      </Grid>
                    </Box>

                    {/* Template list */}
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#1E293B' }}>
                      Existing Custom Templates ({waTemplatesList.length})
                    </Typography>
                    {waTemplatesList.length === 0 ? (
                      <Typography variant="body2" sx={{ color: '#94A3B8', fontStyle: 'italic', py: 1 }}>
                        No custom templates configured yet.
                      </Typography>
                    ) : (
                      <List sx={{ p: 0, maxHeight: 200, overflowY: 'auto' }}>
                        {waTemplatesList.map(tmpl => (
                          <Paper key={tmpl.id} sx={{ p: 1.5, mb: 1, border: '1px solid #E2E8F0', borderRadius: '8px', backgroundColor: 'white' }}>
                            <Box display="flex" justifyContent="space-between" alignItems="center" mb={0.5}>
                              <Typography variant="body2" sx={{ fontWeight: 700, color: '#2563EB' }}>
                                {tmpl.name}
                              </Typography>
                              <IconButton size="small" onClick={() => handleDeleteWaTemplate(tmpl.id)} color="error">
                                <Icons.Trash2 size={16} />
                              </IconButton>
                            </Box>
                            <Typography variant="caption" sx={{ color: '#475569', display: 'block', whiteSpace: 'pre-wrap' }}>
                              {tmpl.body}
                            </Typography>
                          </Paper>
                        ))}
                      </List>
                    )}
                  </CardContent>
                </Card>
              </Grid>

              {/* Right Column: Campaign Setup & Realtime Logs */}
              <Grid item xs={12} md={7}>
                {/* 1. Broadcast Setup Card */}
                <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px', mb: 3 }}>
                  <CardContent sx={{ p: 3 }}>
                    <Box display="flex" alignItems="center" gap={1.5} mb={2}>
                      <Icons.Users size={22} color="#2563EB" />
                      <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '18px', fontFamily: 'Poppins' }}>
                        Bulk WhatsApp Broadcast Campaign
                      </Typography>
                    </Box>

                    <Grid container spacing={3}>
                      {/* Recipient Source Selection */}
                      <Grid item xs={12}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
                          Select Recipient Source
                        </Typography>
                        <FormControl fullWidth size="small">
                          <Select
                            value={waRecipientType}
                            onChange={(e) => setWaRecipientType(e.target.value)}
                          >
                            <MenuItem value="manual">Enter Numbers Manually</MenuItem>
                            <MenuItem value="csv">Upload CSV File</MenuItem>
                          </Select>
                        </FormControl>
                      </Grid>

                      {/* Recipient Inputs */}
                      {waRecipientType === 'manual' ? (
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            multiline
                            rows={3}
                            label="Recipient Numbers (manual entry)"
                            placeholder="Enter phone numbers separated by commas or newlines (e.g. +919999999999, +918888888888)"
                            value={waManualNumbers}
                            onChange={(e) => setWaManualNumbers(e.target.value)}
                          />
                        </Grid>
                      ) : (
                        <Grid item xs={12}>
                          <Box 
                            sx={{ 
                              border: '2px dashed #CBD5E1', 
                              borderRadius: '12px', 
                              p: 3, 
                              textAlign: 'center', 
                              backgroundColor: '#F8FAFC',
                              cursor: 'pointer',
                              '&:hover': { borderColor: '#2563EB' }
                            }}
                            component="label"
                          >
                            <input 
                              type="file" 
                              accept=".csv" 
                              hidden 
                              onChange={handleCsvUpload} 
                            />
                            <Icons.Upload size={32} color="#64748B" style={{ marginBottom: 8 }} />
                            <Typography variant="body2" sx={{ fontWeight: 600, color: '#475569' }}>
                              Click to select and parse CSV file
                            </Typography>
                            <Typography variant="caption" sx={{ color: '#94A3B8', display: 'block', mt: 0.5 }}>
                              Note: Phone numbers should be in the very first column.
                            </Typography>
                            {waCsvNumbers.length > 0 && (
                              <Chip 
                                label={`Successfully loaded ${waCsvNumbers.length} recipients`} 
                                color="success" 
                                size="small" 
                                sx={{ mt: 2 }} 
                              />
                            )}
                          </Box>
                        </Grid>
                      )}

                      {/* Select Template shortcut */}
                      <Grid item xs={12}>
                        <FormControl fullWidth size="small">
                          <InputLabel>Insert Message Template</InputLabel>
                          <Select
                            value={waSelectedTemplate}
                            onChange={(e) => {
                              const val = e.target.value;
                              setWaSelectedTemplate(val);
                              const selected = waTemplatesList.find(t => t.id === val);
                              if (selected) {
                                setWaMessageBody(selected.body);
                              }
                            }}
                            label="Insert Message Template"
                          >
                            <MenuItem value=""><em>None (Write Custom Message)</em></MenuItem>
                            {waTemplatesList.map(t => (
                              <MenuItem key={t.id} value={t.id}>{t.name}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Grid>

                      {/* Message Body */}
                      <Grid item xs={12}>
                        <TextField
                          fullWidth
                          multiline
                          rows={4}
                          label="Message Content"
                          value={waMessageBody}
                          onChange={(e) => setWaMessageBody(e.target.value)}
                        />
                      </Grid>

                      {/* Attachment Selector */}
                      <Grid item xs={12}>
                        <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
                          Add Media Attachment (Photo, Video, PDF or Document)
                        </Typography>
                        <Box display="flex" alignItems="center" gap={2}>
                          <Button
                            variant="outlined"
                            component="label"
                            startIcon={waUploadLoading ? <CircularProgress size={16} /> : <Icons.Upload size={16} />}
                            disabled={waUploadLoading}
                            sx={{ textTransform: 'none', borderRadius: '8px' }}
                          >
                            Upload File
                            <input 
                              type="file" 
                              hidden 
                              onChange={handleMediaUpload} 
                              accept="image/*,video/*,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                            />
                          </Button>
                          {waMediaFile && (
                            <Box display="flex" flexDirection="column">
                              <Typography variant="body2" sx={{ fontWeight: 600, color: '#1E293B' }}>
                                {waMediaFile.name}
                              </Typography>
                              <Typography variant="caption" sx={{ color: '#64748B' }}>
                                Type: {waMediaType.toUpperCase()} ({Math.round(waMediaFile.size / 1024)} KB)
                              </Typography>
                            </Box>
                          )}
                        </Box>
                        {waMediaUrl && (
                          <Typography variant="caption" sx={{ color: '#10B981', mt: 1, display: 'block', wordBreak: 'break-all' }}>
                            File uploaded successfully: <a href={waMediaUrl} target="_blank" rel="noreferrer" style={{ textDecoration: 'underline' }}>{waMediaUrl}</a>
                          </Typography>
                        )}
                      </Grid>

                      {/* Send Button */}
                      <Grid item xs={12}>
                        <Button
                          variant="contained"
                          color="success"
                          fullWidth
                          size="large"
                          disabled={waCampaignLoading}
                          onClick={handleStartCampaign}
                          startIcon={waCampaignLoading ? <CircularProgress size={20} color="inherit" /> : <Icons.Send size={20} />}
                          sx={{ textTransform: 'none', borderRadius: '10px', py: 1.5, fontSize: '15px', fontWeight: 700 }}
                        >
                          {waCampaignLoading ? 'Processing Broadcast Campaign...' : 'Share / Broadcast with Single Click'}
                        </Button>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>

                {/* 2. Realtime Tracking Console (Background Task monitor) */}
                {waCampaignStatus.status !== 'idle' && (
                  <Card sx={{ border: '1px solid #E2E8F0', borderRadius: '16px', backgroundColor: '#020617', color: '#F8FAFC' }}>
                    <CardContent sx={{ p: 3 }}>
                      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                        <Box display="flex" alignItems="center" gap={1.5}>
                          <CircularProgress size={18} thickness={5} color={waCampaignStatus.status === 'sending' ? 'primary' : 'inherit'} />
                          <Typography variant="h3" sx={{ fontWeight: 800, fontSize: '18px', fontFamily: 'Poppins' }}>
                            Campaign Console: {waCampaignStatus.status.toUpperCase()}
                          </Typography>
                        </Box>
                        {waCampaignStatus.status === 'sending' && (
                          <Button 
                            variant="contained" 
                            color="error" 
                            size="small" 
                            onClick={handleAbortCampaign}
                            startIcon={<Icons.XCircle size={14} />}
                            sx={{ textTransform: 'none', borderRadius: '6px', fontSize: '12px' }}
                          >
                            Abort Campaign
                          </Button>
                        )}
                      </Box>

                      {/* Campaign progress details */}
                      <Grid container spacing={2} sx={{ mb: 2 }}>
                        <Grid item xs={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#1E293B', color: 'white' }}>
                            <Typography variant="caption" sx={{ color: '#94A3B8' }}>Total Recipients</Typography>
                            <Typography variant="h4" sx={{ fontWeight: 800, mt: 0.5 }}>{waCampaignStatus.total}</Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#1E293B', color: '#10B981' }}>
                            <Typography variant="caption" sx={{ color: '#94A3B8' }}>Sent</Typography>
                            <Typography variant="h4" sx={{ fontWeight: 800, mt: 0.5 }}>{waCampaignStatus.sent}</Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#1E293B', color: '#EF4444' }}>
                            <Typography variant="caption" sx={{ color: '#94A3B8' }}>Failed</Typography>
                            <Typography variant="h4" sx={{ fontWeight: 800, mt: 0.5 }}>{waCampaignStatus.failed}</Typography>
                          </Paper>
                        </Grid>
                      </Grid>

                      {/* Progress Bar */}
                      <Box sx={{ mb: 3 }}>
                        <Box display="flex" justifyContent="space-between" mb={0.5}>
                          <Typography variant="caption" sx={{ color: '#94A3B8' }}>Broadcast Progress</Typography>
                          <Typography variant="caption" sx={{ color: '#94A3B8' }}>
                            {Math.round(((waCampaignStatus.sent + waCampaignStatus.failed) / waCampaignStatus.total) * 100) || 0}%
                          </Typography>
                        </Box>
                        <LinearProgress 
                          variant="determinate" 
                          value={((waCampaignStatus.sent + waCampaignStatus.failed) / waCampaignStatus.total) * 100 || 0} 
                          sx={{ height: 8, borderRadius: 4, backgroundColor: '#334155', '& .MuiLinearProgress-bar': { borderRadius: 4 } }}
                        />
                      </Box>

                      {/* Log Screen */}
                      <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#94A3B8' }}>
                        Live Broadcast Logs
                      </Typography>
                      <Box 
                        sx={{ 
                          height: 180, 
                          overflowY: 'auto', 
                          fontFamily: 'monospace', 
                          fontSize: '12px', 
                          p: 2, 
                          backgroundColor: '#0F172A', 
                          border: '1px solid #1E293B', 
                          borderRadius: '8px',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: 0.5
                        }}
                      >
                        {waCampaignStatus.logs.slice().reverse().map((log, idx) => (
                          <Typography 
                            key={idx} 
                            variant="caption" 
                            sx={{ 
                              color: log.includes('[Sent]') ? '#10B981' : log.includes('[Failed]') ? '#EF4444' : '#E2E8F0',
                              fontFamily: 'monospace'
                            }}
                          >
                            {log}
                          </Typography>
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                )}
              </Grid>
            </Grid>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Settings;
